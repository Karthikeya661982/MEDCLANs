import { UserHealthProfile, EmergencyContact, MedicalRecord, Appointment } from '../types';

const DB_NAME = 'MedClanIndexedDB';
const DB_VERSION = 1;

export const STORES = {
  HEALTH_PROFILE: 'healthProfile',
  EMERGENCY_CONTACTS: 'emergencyContacts',
  MEDICAL_RECORDS: 'medicalRecords',
  APPOINTMENTS: 'appointments',
};

// Helper to open or upgrade IndexedDB
export const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB is not supported by this browser environment.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // 1. Health Profile Store
      if (!db.objectStoreNames.contains(STORES.HEALTH_PROFILE)) {
        db.createObjectStore(STORES.HEALTH_PROFILE, { keyPath: 'id' });
      }

      // 2. Emergency Contacts Store
      if (!db.objectStoreNames.contains(STORES.EMERGENCY_CONTACTS)) {
        const contactStore = db.createObjectStore(STORES.EMERGENCY_CONTACTS, { keyPath: 'id' });
        contactStore.createIndex('phone', 'phone', { unique: false });
      }

      // 3. Medical Records Store
      if (!db.objectStoreNames.contains(STORES.MEDICAL_RECORDS)) {
        const recordsStore = db.createObjectStore(STORES.MEDICAL_RECORDS, { keyPath: 'id' });
        recordsStore.createIndex('category', 'category', { unique: false });
        recordsStore.createIndex('date', 'date', { unique: false });
      }

      // 4. Appointments Store
      if (!db.objectStoreNames.contains(STORES.APPOINTMENTS)) {
        db.createObjectStore(STORES.APPOINTMENTS, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error || new Error('Failed to open IndexedDB'));
    };
  });
};

// ==================== HEALTH PROFILE IDB API ====================

export const getHealthProfileFromIDB = async (): Promise<UserHealthProfile | null> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.HEALTH_PROFILE, 'readonly');
      const store = tx.objectStore(STORES.HEALTH_PROFILE);
      const req = store.get('current');

      req.onsuccess = () => {
        if (req.result) {
          const { id, ...profile } = req.result;
          resolve(profile as UserHealthProfile);
        } else {
          resolve(null);
        }
      };

      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('IDB getHealthProfile error:', err);
    return null;
  }
};

export const saveHealthProfileToIDB = async (profile: UserHealthProfile): Promise<void> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.HEALTH_PROFILE, 'readwrite');
      const store = tx.objectStore(STORES.HEALTH_PROFILE);
      const req = store.put({ id: 'current', ...profile, updatedAt: new Date().toISOString() });

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('IDB saveHealthProfile error:', err);
  }
};

// ==================== EMERGENCY CONTACTS IDB API ====================

export const getEmergencyContactsFromIDB = async (): Promise<EmergencyContact[]> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.EMERGENCY_CONTACTS, 'readonly');
      const store = tx.objectStore(STORES.EMERGENCY_CONTACTS);
      const req = store.getAll();

      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('IDB getEmergencyContacts error:', err);
    return [];
  }
};

export const saveEmergencyContactToIDB = async (contact: EmergencyContact): Promise<void> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.EMERGENCY_CONTACTS, 'readwrite');
      const store = tx.objectStore(STORES.EMERGENCY_CONTACTS);
      const req = store.put(contact);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('IDB saveEmergencyContact error:', err);
  }
};

export const deleteEmergencyContactFromIDB = async (id: string): Promise<void> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.EMERGENCY_CONTACTS, 'readwrite');
      const store = tx.objectStore(STORES.EMERGENCY_CONTACTS);
      const req = store.delete(id);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('IDB deleteEmergencyContact error:', err);
  }
};

// ==================== MEDICAL RECORDS IDB API ====================

export const getMedicalRecordsFromIDB = async (): Promise<MedicalRecord[]> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.MEDICAL_RECORDS, 'readonly');
      const store = tx.objectStore(STORES.MEDICAL_RECORDS);
      const req = store.getAll();

      req.onsuccess = () => {
        const records: MedicalRecord[] = req.result || [];
        // Sort descending by date
        records.sort((a, b) => new Date(b.createdAt || b.date).getTime() - new Date(a.createdAt || a.date).getTime());
        resolve(records);
      };

      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('IDB getMedicalRecords error:', err);
    return [];
  }
};

export const saveMedicalRecordToIDB = async (record: MedicalRecord): Promise<void> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.MEDICAL_RECORDS, 'readwrite');
      const store = tx.objectStore(STORES.MEDICAL_RECORDS);
      const req = store.put(record);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('IDB saveMedicalRecord error:', err);
  }
};

export const deleteMedicalRecordFromIDB = async (id: string): Promise<void> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.MEDICAL_RECORDS, 'readwrite');
      const store = tx.objectStore(STORES.MEDICAL_RECORDS);
      const req = store.delete(id);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('IDB deleteMedicalRecord error:', err);
  }
};

// ==================== APPOINTMENTS IDB API ====================

export const getAppointmentsFromIDB = async (): Promise<Appointment[]> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.APPOINTMENTS, 'readonly');
      const store = tx.objectStore(STORES.APPOINTMENTS);
      const req = store.getAll();

      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('IDB getAppointments error:', err);
    return [];
  }
};

export const saveAppointmentToIDB = async (appointment: Appointment): Promise<void> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.APPOINTMENTS, 'readwrite');
      const store = tx.objectStore(STORES.APPOINTMENTS);
      const req = store.put(appointment);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('IDB saveAppointment error:', err);
  }
};

// ==================== SEED INITIAL DEMO DATA INTO IDB ====================

export const seedInitialOfflineStorage = async (
  defaultProfile: UserHealthProfile,
  defaultAppointments: Appointment[]
): Promise<{ profile: UserHealthProfile; contacts: EmergencyContact[]; records: MedicalRecord[]; appointments: Appointment[] }> => {
  try {
    // 1. Health Profile
    let profile = await getHealthProfileFromIDB();
    if (!profile) {
      profile = defaultProfile;
      await saveHealthProfileToIDB(profile);
    }

    // 2. Emergency Contacts
    let contacts = await getEmergencyContactsFromIDB();
    if (!contacts || contacts.length === 0) {
      contacts = (defaultProfile.emergencyContacts || []).map((c, i) => ({
        id: `ec-${i + 1}`,
        name: c.name,
        relation: c.relation,
        phone: c.phone,
        isPrimary: i === 0,
      }));
      for (const c of contacts) {
        await saveEmergencyContactToIDB(c);
      }
    }

    // 3. Medical Records
    let records = await getMedicalRecordsFromIDB();
    if (!records || records.length === 0) {
      const initialRecords: MedicalRecord[] = [
        {
          id: 'rec-101',
          title: 'Cardiology OPD Consultation & ECG Report',
          category: 'Prescription',
          doctorName: 'Dr. Arvind Swaminathan',
          hospitalName: 'Apollo Super Specialty Hospital',
          date: '2026-07-10',
          notes: 'Prescribed Atorvastatin 10mg daily. Sinus rhythm normal on ECG.',
          tags: ['Cardiology', 'ECG', 'Hypertension'],
          createdAt: new Date('2026-07-10').toISOString(),
        },
        {
          id: 'rec-102',
          title: 'Comprehensive Lipid Profile & CBC Test',
          category: 'Lab Report',
          doctorName: 'Dr. Sunita Deshmukh',
          hospitalName: 'Vijaya Diagnostic Center',
          date: '2026-06-25',
          notes: 'Total Cholesterol: 185 mg/dL, HDL: 48 mg/dL, Triglycerides: 140 mg/dL.',
          tags: ['Lab', 'Blood Test', 'Cholesterol'],
          createdAt: new Date('2026-06-25').toISOString(),
        },
        {
          id: 'rec-103',
          title: 'Chest X-Ray (PA View)',
          category: 'Imaging / X-Ray',
          doctorName: 'Dr. Rajesh K. Varma',
          hospitalName: 'Max Care Diagnostics',
          date: '2026-05-18',
          notes: 'Lung fields clear. No focal consolidation or pleural effusion.',
          tags: ['Radiology', 'X-Ray'],
          createdAt: new Date('2026-05-18').toISOString(),
        },
      ];
      for (const r of initialRecords) {
        await saveMedicalRecordToIDB(r);
      }
      records = initialRecords;
    }

    // 4. Appointments
    let appointments = await getAppointmentsFromIDB();
    if (!appointments || appointments.length === 0) {
      appointments = defaultAppointments;
      for (const a of appointments) {
        await saveAppointmentToIDB(a);
      }
    }

    return { profile, contacts, records, appointments };
  } catch (err) {
    console.error('Error seeding initial IndexedDB offline storage:', err);
    return {
      profile: defaultProfile,
      contacts: (defaultProfile.emergencyContacts || []).map((c, i) => ({
        id: `ec-${i + 1}`,
        name: c.name,
        relation: c.relation,
        phone: c.phone,
        isPrimary: i === 0,
      })),
      records: [],
      appointments: defaultAppointments,
    };
  }
};
