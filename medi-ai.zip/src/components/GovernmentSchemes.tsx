import React, { useState } from 'react';
import { Landmark, Sparkles, CheckCircle2, FileText, ExternalLink, ShieldCheck, ArrowRight } from 'lucide-react';
import { MOCK_GOVT_SCHEMES } from '../data/mockData';

export const GovernmentSchemes: React.FC = () => {
  const [income, setIncome] = useState('Below ₹2.5 Lakhs / year');
  const [age, setAge] = useState(38);
  const [gender, setGender] = useState('Male');
  const [state, setState] = useState('Telangana / Andhra Pradesh');
  const [occupation, setOccupation] = useState('Informal Sector / Self-Employed');
  const [disease, setDisease] = useState('Heart Surgery / Cardiac Care');

  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any | null>(null);

  const handleCheckEligibility = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/ai/scheme-eligibility', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ income, age, gender, state, occupation, disease }),
      });
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error("Scheme Engine Error", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950/30 to-slate-950 p-6 sm:p-8 rounded-3xl border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 bg-amber-500/10 text-amber-400 px-3 py-1 rounded-full text-xs font-bold border border-amber-500/30">
              <Landmark className="w-3.5 h-3.5" />
              <span>Ayushman Bharat & State Relief Scheme Intelligence</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Government Scheme Eligibility Checker
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Find free healthcare coverage and financial relief grants up to ₹5,00,000 for your family under Central and State Government medical schemes.
            </p>
          </div>

          <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 text-center space-y-1">
            <span className="text-xs text-slate-400 font-bold uppercase block">PM-JAY INTEGRATED</span>
            <span className="text-sm font-bold text-amber-400">28,000+ Empanelled Network</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Questionnaire Form */}
        <div className="lg:col-span-5 bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-5 shadow-xl">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            Family Demographic & Medical Questionnaire
          </h3>

          <div className="space-y-4 text-xs">
            
            <div>
              <label className="text-slate-400 font-bold block mb-1">ANNUAL FAMILY INCOME LEVEL</label>
              <select
                value={income}
                onChange={(e) => setIncome(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
              >
                <option>Below ₹2.5 Lakhs / year (BPL / Ration Card Holder)</option>
                <option>₹2.5 Lakhs - ₹5.0 Lakhs / year</option>
                <option>₹5.0 Lakhs - ₹8.0 Lakhs / year</option>
                <option>Above ₹8.0 Lakhs / year</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 font-bold block mb-1">PATIENT AGE</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">GENDER</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-400 font-bold block mb-1">RESIDENTIAL STATE</label>
              <select
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
              >
                <option>Telangana / Andhra Pradesh (Aarogyasri)</option>
                <option>Maharashtra (Mahatma Jyotirao Phule Jan Arogya)</option>
                <option>Tamil Nadu (Chief Minister Comprehensive Health)</option>
                <option>Karnataka (Arogya Karnataka)</option>
                <option>Kerala (KASP / Karunya Scheme)</option>
                <option>Delhi / NCR / Uttar Pradesh</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 font-bold block mb-1">OCCUPATION TYPE</label>
              <select
                value={occupation}
                onChange={(e) => setOccupation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
              >
                <option>Informal Sector / Self-Employed</option>
                <option>Agricultural Worker / Farmer</option>
                <option>Private Sector Employee</option>
                <option>Senior Citizen / Pensioner</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 font-bold block mb-1">MEDICAL CONDITION / DISEASE</label>
              <input
                type="text"
                value={disease}
                onChange={(e) => setDisease(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              onClick={handleCheckEligibility}
              disabled={loading}
              className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-amber-500 to-teal-500 text-slate-950 font-black text-sm rounded-xl shadow-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
            >
              {loading ? "Matching Schemes..." : "Check Eligible Government Schemes"}
              <ArrowRight className="w-4 h-4" />
            </button>

          </div>
        </div>

        {/* Results Output */}
        <div className="lg:col-span-7 bg-slate-900/90 p-6 sm:p-8 rounded-3xl border border-slate-800/90 space-y-6">
          {results ? (
            <div className="space-y-6">
              
              {/* Eligibility Score Header */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-500/20 via-teal-500/10 to-slate-950 border border-amber-500/30 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">ELIGIBILITY MATCH SCORE</span>
                  <h3 className="text-3xl font-black text-white font-mono mt-0.5">
                    {results.eligibilityScore}% HIGH QUALIFIED
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">Found <strong className="text-white">{results.matchingSchemes?.length} Eligible Healthcare Relief Schemes</strong></p>
                </div>

                <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-black text-xl font-mono">
                  {results.eligibilityScore}
                </div>
              </div>

              {/* Matching Schemes List */}
              <div className="space-y-4">
                {results.matchingSchemes?.map((sch: any, idx: number) => (
                  <div key={idx} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          {sch.name}
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/30">
                            {sch.eligibilityStatus}
                          </span>
                        </h4>
                        <span className="text-xs font-mono font-bold text-teal-400 block mt-1">
                          Max Benefit: {sch.maxBenefit}
                        </span>
                      </div>

                      <a
                        href={sch.applyUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1 shadow-md shrink-0"
                      >
                        Apply Online <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-300">
                      <p className="font-semibold text-slate-400">Key Benefits:</p>
                      <ul className="list-disc list-inside space-y-0.5 text-slate-300 pl-1">
                        {sch.keyFeatures?.map((f: string, fIdx: number) => (
                          <li key={fIdx}>{f}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-2 border-t border-slate-900 flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                      <span className="font-bold text-slate-300">Required Documents:</span>
                      {sch.documentsNeeded?.map((doc: string, dIdx: number) => (
                        <span key={dIdx} className="bg-slate-900 px-2 py-0.5 rounded text-slate-300">
                          {doc}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

            </div>
          ) : (
            <div className="py-24 text-center space-y-3">
              <Landmark className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-400">Fill in family income and details on the left to discover matching government schemes and direct application links.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
