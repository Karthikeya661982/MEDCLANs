import React, { useState } from 'react';
import { Stethoscope, Bot, ShieldAlert, Play, ArrowRight, ShieldCheck, Zap, Activity, Award, CheckCircle2, TrendingDown, Users, HeartPulse } from 'lucide-react';

interface HeroProps {
  onNavigate: (tab: string) => void;
  onTriggerSOS: () => void;
}


export const Hero: React.FC<HeroProps> = ({ onNavigate, onTriggerSOS }) => {
  const [demoVideoOpen, setDemoVideoOpen] = useState(false);

  const stats = [
    { label: "Verified Nearby Doctors", value: "8,500+", icon: Stethoscope, color: "text-teal-400" },
    { label: "Bill Fraud Detection Rate", value: "99.8%", icon: ShieldCheck, color: "text-emerald-400" },
    { label: "Patient Savings Generated", value: "₹14.2 Cr+", icon: TrendingDown, color: "text-cyan-400" },
    { label: "Emergency SOS Responded", value: "18,400+", icon: Zap, color: "text-rose-400" },
  ];

  const badges = [
    "ABDM Digital Health Accredited",
    "ISO 27001 Encrypted Patient Data",
    "Ayushman Bharat PM-JAY Integrated",
    "NABH Empanelled Network",
  ];

  return (
    <div className="relative min-h-[90vh] flex flex-col justify-between overflow-hidden bg-slate-950 pt-10 pb-16 border-b border-slate-900">
      
      {/* Background Aurora Mesh Gradients & Particle Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-tr from-teal-500/15 via-cyan-500/10 to-emerald-500/15 blur-[140px] pointer-events-none rounded-full" />
      <div className="absolute top-1/3 right-0 w-80 h-80 bg-rose-500/10 blur-[120px] pointer-events-none rounded-full" />

      {/* Animated Medical Heartbeat SVG Canvas Wave */}
      <div className="absolute inset-x-0 top-1/4 h-64 pointer-events-none opacity-20">
        <svg className="w-full h-full" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path
            d="M 0,60 L 300,60 L 320,10 L 340,110 L 360,30 L 380,80 L 400,60 L 700,60 L 720,5 L 740,115 L 760,20 L 780,90 L 800,60 L 1200,60"
            fill="none"
            stroke="#14b8a6"
            strokeWidth="2.5"
            className="animate-pulse"
          />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 my-auto">
        
        {/* Top Floating Pill Tagline */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center space-x-2 bg-slate-900/90 border border-teal-500/30 px-4 py-2 rounded-full shadow-2xl backdrop-blur-md hover:border-teal-500/60 transition-all cursor-pointer group">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500" />
            </span>
            <span className="text-xs font-bold tracking-wider text-slate-200 uppercase font-mono">
              Tagline: "Saving Lives Faster, Smarter & More Affordable."
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-teal-400 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Main Hero Headline */}
        <div className="text-center max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-white tracking-tight leading-[1.1]">
            AI Healthcare Platform for{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-cyan-300 to-emerald-400">
              Every Emergency
            </span>
          </h1>

          <p className="text-base sm:text-xl text-slate-300 font-normal max-w-3xl mx-auto leading-relaxed">
            Find nearby doctors instantly • Estimate treatment costs • Compare hospitals • Avoid fraudulent medical bills • Discover government schemes • Get AI-powered healthcare assistance.
          </p>

          {/* Action Call To Action Buttons */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
            
            {/* Button 1: Find Doctor */}
            <button
              onClick={() => onNavigate('doctors')}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-teal-400 via-teal-500 to-cyan-500 text-slate-950 font-black text-sm tracking-wide shadow-xl shadow-teal-500/25 hover:shadow-teal-500/40 hover:scale-105 transition-all flex items-center space-x-2.5"
            >
              <Stethoscope className="w-5 h-5" />
              <span>Find Doctor</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            {/* Button 2: Talk to AI */}
            <button
              onClick={() => onNavigate('chatbot')}
              className="px-6 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm tracking-wide border border-slate-700 shadow-xl hover:border-teal-500/50 hover:scale-105 transition-all flex items-center space-x-2.5"
            >
              <Bot className="w-5 h-5 text-teal-400" />
              <span>Talk to AI</span>
            </button>

            {/* Button 3: Emergency SOS */}
            <button
              onClick={onTriggerSOS}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-sm tracking-wide shadow-xl shadow-rose-600/30 hover:scale-105 transition-all flex items-center space-x-2.5 animate-pulse"
            >
              <ShieldAlert className="w-5 h-5 text-white" />
              <span>Emergency SOS</span>
            </button>

            {/* Button 4: Watch Demo */}
            <button
              onClick={() => setDemoVideoOpen(true)}
              className="px-5 py-3.5 rounded-2xl bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white text-sm font-semibold border border-slate-800 flex items-center space-x-2 transition-all"
            >
              <div className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center">
                <Play className="w-3.5 h-3.5 fill-teal-400" />
              </div>
              <span>Watch Demo</span>
            </button>


          </div>

          {/* Quick Accreditations Row */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-3 text-xs text-slate-400">
            {badges.map((b, idx) => (
              <span key={idx} className="flex items-center space-x-1.5 bg-slate-900/80 px-3 py-1.5 rounded-lg border border-slate-800/80">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
                <span>{b}</span>
              </span>
            ))}
          </div>

        </div>

        {/* Floating Metrics Counter Grid */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto">
          {stats.map((s, i) => {
            const Icon = s.icon;
            return (
              <div
                key={i}
                className="bg-slate-900/70 backdrop-blur-xl p-5 rounded-2xl border border-slate-800/90 hover:border-teal-500/30 transition-all hover:-translate-y-1 group"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2 rounded-xl bg-slate-800/80 ${s.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">VERIFIED</span>
                </div>
                <div className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight group-hover:text-teal-300 transition-colors">
                  {s.value}
                </div>
                <div className="text-xs text-slate-400 font-medium mt-1">
                  {s.label}
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Interactive Video Tour Modal */}
      {demoVideoOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-xl p-4">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <HeartPulse className="w-5 h-5 text-teal-400" />
                MEDI AI - Complete Platform Overview Video
              </h3>
              <button
                onClick={() => setDemoVideoOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                ✕
              </button>
            </div>

            <div className="relative aspect-video rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col items-center justify-center text-center p-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center animate-bounce">
                <Activity className="w-8 h-8 text-teal-400" />
              </div>
              <div className="space-y-2">
                <h4 className="text-xl font-bold text-white">Interactive Demonstration Active</h4>
                <p className="text-xs text-slate-400 max-w-md">
                  Experience live AI bill fraud detection, emergency SOS GPS dispatcher, treatment cost estimations, and doctor consultations directly in the interactive interface below.
                </p>
              </div>
              <button
                onClick={() => {
                  setDemoVideoOpen(false);
                  onNavigate('doctors');
                }}
                className="px-5 py-2.5 bg-teal-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg"
              >
                Launch Live Interactive Tour
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
