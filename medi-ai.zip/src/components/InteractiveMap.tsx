import React, { useState } from 'react';
import { MapPin, Navigation, NavigationOff, ShieldAlert, Phone, Crosshair, Star, Clock } from 'lucide-react';
import { Doctor, Hospital, BloodBank, Pharmacy } from '../types';

interface InteractiveMapProps {
  doctors?: Doctor[];
  hospitals?: Hospital[];
  bloodBanks?: BloodBank[];
  pharmacies?: Pharmacy[];
  centerLat?: number;
  centerLng?: number;
  activeItemType?: 'doctors' | 'hospitals' | 'blood' | 'pharmacies' | 'ambulance';
  selectedId?: string;
  onSelectItem?: (item: any) => void;
  showRoute?: boolean;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  doctors = [],
  hospitals = [],
  bloodBanks = [],
  pharmacies = [],
  activeItemType = 'doctors',
  selectedId,
  onSelectItem,
  showRoute = false,
}) => {
  const [zoom, setZoom] = useState(14);
  const [activeTab, setActiveTab] = useState<'all' | 'doctors' | 'hospitals' | 'blood' | 'pharmacies'>(
    activeItemType === 'ambulance' ? 'all' : activeItemType
  );
  const [hoveredItem, setHoveredItem] = useState<any | null>(null);

  // Simulated GPS center (Hyderabad Jubilee Hills)
  const userLocation = { lat: 17.4300, lng: 78.4100, name: "Your Current Location" };

  // Calculate relative map coordinates (percent offset inside container)
  const getMapCoordinates = (lat: number, lng: number) => {
    // Map bounding box around Hyderabad
    const minLat = 17.3600;
    const maxLat = 17.4600;
    const minLng = 78.3900;
    const maxLng = 78.5100;

    const y = 100 - ((lat - minLat) / (maxLat - minLat)) * 100;
    const x = ((lng - minLng) / (maxLng - minLng)) * 100;

    return {
      x: Math.min(Math.max(x, 8), 92),
      y: Math.min(Math.max(y, 8), 92),
    };
  };

  const userPos = getMapCoordinates(userLocation.lat, userLocation.lng);

  return (
    <div className="relative w-full h-[520px] bg-slate-950 rounded-2xl border border-slate-800/80 overflow-hidden shadow-2xl group select-none">
      {/* Dark Vector Map Overlay Background with grid lines */}
      <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px]" />

      {/* Futuristic Animated Map Grid Lines & Radar Sweep */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
        <line x1="0" y1="25%" x2="100%" y2="25%" stroke="#0284c7" strokeDasharray="4 4" />
        <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#0284c7" strokeDasharray="4 4" />
        <line x1="0" y1="75%" x2="100%" y2="75%" stroke="#0284c7" strokeDasharray="4 4" />
        <line x1="25%" y1="0" x2="25%" y2="100%" stroke="#0284c7" strokeDasharray="4 4" />
        <line x1="50%" y1="0" x2="50%" y2="100%" stroke="#0284c7" strokeDasharray="4 4" />
        <line x1="75%" y1="0" x2="75%" y2="100%" stroke="#0284c7" strokeDasharray="4 4" />

        {/* Route line connecting User to Selected Item */}
        {showRoute && hoveredItem && (
          <path
            d={`M ${userPos.x}% ${userPos.y}% Q ${(userPos.x + getMapCoordinates(hoveredItem.lat, hoveredItem.lng).x)/2 + 5}% ${(userPos.y + getMapCoordinates(hoveredItem.lat, hoveredItem.lng).y)/2 - 5}% ${getMapCoordinates(hoveredItem.lat, hoveredItem.lng).x}% ${getMapCoordinates(hoveredItem.lat, hoveredItem.lng).y}%`}
            fill="none"
            stroke="#10b981"
            strokeWidth="3"
            strokeDasharray="6 6"
            className="animate-pulse"
          />
        )}
      </svg>

      {/* Top Map Layer Controls & Filters */}
      <div className="absolute top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 backdrop-blur-md p-2.5 rounded-xl border border-slate-800">
        <div className="flex items-center space-x-1.5 overflow-x-auto">
          {(['all', 'doctors', 'hospitals', 'blood', 'pharmacies'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all whitespace-nowrap ${
                activeTab === tab
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-600 text-white shadow-lg shadow-teal-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-300">
          <span className="flex items-center space-x-1 bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full border border-emerald-500/30 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping mr-1" />
            Live GPS Sync Active
          </span>
          <button
            onClick={() => setZoom((z) => (z === 14 ? 16 : 14))}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700"
            title="Recenter Map"
          >
            <Crosshair className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* User Current Location Marker */}
      <div
        style={{ left: `${userPos.x}%`, top: `${userPos.y}%` }}
        className="absolute z-30 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none"
      >
        <div className="relative flex items-center justify-center">
          <span className="absolute w-12 h-12 rounded-full bg-teal-500/20 animate-ping" />
          <span className="absolute w-7 h-7 rounded-full bg-teal-500/40" />
          <div className="w-5 h-5 rounded-full bg-teal-400 border-2 border-white shadow-xl flex items-center justify-center text-[10px] text-slate-950 font-bold">
            YOU
          </div>
        </div>
      </div>

      {/* Doctor Map Pins */}
      {(activeTab === 'all' || activeTab === 'doctors') &&
        doctors.map((doc) => {
          const pos = getMapCoordinates(doc.lat, doc.lng);
          const isSelected = selectedId === doc.id;
          return (
            <div
              key={doc.id}
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
              onClick={() => {
                onSelectItem?.(doc);
                setHoveredItem(doc);
              }}
              onMouseEnter={() => setHoveredItem(doc)}
              className={`absolute z-20 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-300 ${
                isSelected ? 'scale-125 z-40' : 'hover:scale-110'
              }`}
            >
              <div className="relative group/pin">
                <div
                  className={`p-2 rounded-full shadow-xl border ${
                    isSelected
                      ? 'bg-teal-500 text-slate-950 border-white ring-4 ring-teal-500/30'
                      : 'bg-slate-900 text-teal-400 border-teal-500/40 hover:bg-teal-600 hover:text-white'
                  }`}
                >
                  <MapPin className="w-4 h-4" />
                </div>
                {/* Micro Label */}
                <span className="absolute left-1/2 -bottom-5 transform -translate-x-1/2 bg-slate-900/90 text-[10px] text-teal-300 px-1.5 py-0.5 rounded border border-slate-700 whitespace-nowrap opacity-80 group-hover/pin:opacity-100">
                  {doc.name.split(' ')[1] || doc.name} ({doc.distanceKm}km)
                </span>
              </div>
            </div>
          );
        })}

      {/* Hospital Map Pins */}
      {(activeTab === 'all' || activeTab === 'hospitals') &&
        hospitals.map((hosp) => {
          const pos = getMapCoordinates(hosp.lat, hosp.lng);
          const isSelected = selectedId === hosp.id;
          return (
            <div
              key={hosp.id}
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
              onClick={() => {
                onSelectItem?.(hosp);
                setHoveredItem(hosp);
              }}
              onMouseEnter={() => setHoveredItem(hosp)}
              className={`absolute z-20 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-300 ${
                isSelected ? 'scale-125 z-40' : 'hover:scale-110'
              }`}
            >
              <div className="relative group/pin">
                <div
                  className={`p-2 rounded-full shadow-xl border ${
                    isSelected
                      ? 'bg-rose-500 text-white border-white ring-4 ring-rose-500/30'
                      : 'bg-slate-900 text-rose-400 border-rose-500/40 hover:bg-rose-600 hover:text-white'
                  }`}
                >
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <span className="absolute left-1/2 -bottom-5 transform -translate-x-1/2 bg-slate-900/90 text-[10px] text-rose-300 px-1.5 py-0.5 rounded border border-slate-700 whitespace-nowrap opacity-80 group-hover/pin:opacity-100">
                  {hosp.name.split(' ')[0]} ({hosp.icuBedsAvailable} ICU)
                </span>
              </div>
            </div>
          );
        })}

      {/* Blood Bank Pins */}
      {(activeTab === 'all' || activeTab === 'blood') &&
        bloodBanks.map((bb) => {
          const pos = getMapCoordinates(bb.lat, bb.lng);
          return (
            <div
              key={bb.id}
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
              onClick={() => {
                onSelectItem?.(bb);
                setHoveredItem(bb);
              }}
              onMouseEnter={() => setHoveredItem(bb)}
              className="absolute z-20 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all hover:scale-110"
            >
              <div className="p-2 rounded-full bg-slate-900 text-red-500 border border-red-500/50 shadow-lg">
                <div className="w-3 h-3 rounded-full bg-red-600 animate-pulse" />
              </div>
            </div>
          );
        })}

      {/* Hover Info Card Drawer */}
      {hoveredItem && (
        <div className="absolute bottom-4 left-4 right-4 z-30 bg-slate-900/95 backdrop-blur-xl p-4 rounded-xl border border-slate-800 shadow-2xl flex items-center justify-between text-slate-100 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-lg bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <Navigation className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                {hoveredItem.name || hoveredItem.hospitalName}
                {hoveredItem.rating && (
                  <span className="inline-flex items-center gap-1 text-xs text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20">
                    <Star className="w-3 h-3 fill-amber-400" />
                    {hoveredItem.rating}
                  </span>
                )}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {hoveredItem.address || hoveredItem.specialty} • <span className="text-teal-400 font-medium">{hoveredItem.distanceKm} km away</span>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <a
              href={`tel:${hoveredItem.phone || '+914023607777'}`}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-teal-400" />
              Call
            </a>
            <button
              onClick={() => onSelectItem?.(hoveredItem)}
              className="px-3.5 py-1.5 bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-400 hover:to-cyan-500 text-slate-950 font-bold text-xs rounded-lg shadow-md shadow-teal-500/20"
            >
              View Details
            </button>
          </div>
        </div>
      )}

      {/* Bottom Map Legend */}
      <div className="absolute bottom-4 right-4 z-10 hidden sm:flex items-center space-x-3 text-[11px] bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-slate-400">
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-teal-400" /> Doctor</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Hospital</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-600" /> Blood Bank</span>
      </div>
    </div>
  );
};
