import React, { useState } from 'react';
import { UserCheck, Video, Calendar, Clock, DollarSign, FileText, CheckCircle2, ShieldAlert, Plus, Stethoscope, Search } from 'lucide-react';
import { Appointment } from '../types';

interface DoctorDashboardProps {
  appointments: Appointment[];
  onLaunchVideoConsultation?: (apt: Appointment) => void;
}

export const DoctorDashboard: React.FC = () => {
  const [isOnline, setIsOnline] = useState(true);
  const [showRxModal, setShowRxModal] = useState(false);
  const [activePatient, setActivePatient] = useState('Karthikeya Sharma');

  const [rxForm, setRxForm] = useState({
    medicines: '1) Atorvastatin 10mg - Night x 30 days\n2) Pantoprazole 40mg - Morning x 15 days',
    diagnosis: 'Mild Hypertension & Lipid Management',
    advice: 'Low salt diet, 30 mins brisk walking daily.',
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Doctor Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <img
            src="https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=300"
            className="w-16 h-16 rounded-2xl object-cover border-2 border-teal-500 shadow-lg"
          />
          <div>
            <h2 className="text-2xl font-black text-white flex items-center gap-2">
              Dr. Arvind Swaminathan
              <span className="text-xs bg-teal-500/10 text-teal-300 font-bold px-2 py-0.5 rounded border border-teal-500/20">
                Cardiologist (MD, DM)
              </span>
            </h2>
            <p className="text-xs text-slate-400">Apollo Super Specialty Hospital • Reg #TS-MEDICAL-884920</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-slate-950 p-2.5 rounded-2xl border border-slate-800">
            <span className={`w-3 h-3 rounded-full ${isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
            <span className="text-xs font-bold text-white">{isOnline ? 'ONLINE FOR VIDEO CONSULT' : 'OFFLINE'}</span>
            <button
              onClick={() => setIsOnline(!isOnline)}
              className="ml-2 text-[10px] bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded text-slate-300"
            >
              Toggle
            </button>
          </div>

          <button
            onClick={() => setShowRxModal(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-teal-400 to-cyan-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Write e-Prescription
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold block">TODAY'S CONSULTATIONS</span>
          <div className="text-3xl font-black text-white font-mono">14 Patients</div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold block">URGENT TRIAGE QUEUE</span>
          <div className="text-3xl font-black text-rose-400 font-mono">2 Critical</div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold block">AVG CONSULT TIME</span>
          <div className="text-3xl font-black text-cyan-400 font-mono">11 Mins</div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-emerald-400 font-bold block">TODAY'S EARNINGS</span>
          <div className="text-3xl font-black text-emerald-400 font-mono">₹16,800</div>
        </div>
      </div>

      {/* Patient Waiting Queue */}
      <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-teal-400" />
          Patient Consultation Waiting Queue
        </h3>

        <div className="space-y-3">
          {[
            { name: "Karthikeya Sharma", age: 34, symptom: "Chest Pressure & Shortness of Breath", triage: "URGENT", time: "03:30 PM", fee: 1200 },
            { name: "Priya Sundaram", age: 42, symptom: "Post-op Angioplasty Followup", triage: "ROUTINE", time: "04:15 PM", fee: 1200 },
            { name: "Rajesh Varma", age: 61, symptom: "High BP & Palpitations", triage: "ROUTINE", time: "05:00 PM", fee: 1200 },
          ].map((pat, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <h4 className="text-sm font-bold text-white">{pat.name}</h4>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${pat.triage === 'URGENT' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse' : 'bg-slate-800 text-slate-300'}`}>
                    {pat.triage}
                  </span>
                </div>
                <p className="text-xs text-slate-400">Age: {pat.age} • Symptoms: <span className="text-slate-200">{pat.symptom}</span></p>
                <p className="text-[11px] text-teal-400 font-mono">Scheduled Slot: {pat.time}</p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    setActivePatient(pat.name);
                    setShowRxModal(true);
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl"
                >
                  Write Rx
                </button>

                <button
                  onClick={() => alert(`Launching HD Video Call Room with ${pat.name}`)}
                  className="px-4 py-2 bg-gradient-to-r from-teal-400 to-cyan-500 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 shadow"
                >
                  <Video className="w-3.5 h-3.5" /> Start Video
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Write e-Prescription Modal */}
      {showRxModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xl p-4">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 text-slate-100 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white">Digital e-Prescription Writer</h3>
              <button onClick={() => setShowRxModal(false)} className="text-slate-400">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-bold block mb-1">PATIENT NAME</label>
                <input
                  type="text"
                  value={activePatient}
                  onChange={(e) => setActivePatient(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">DIAGNOSIS & NOTES</label>
                <input
                  type="text"
                  value={rxForm.diagnosis}
                  onChange={(e) => setRxForm({ ...rxForm, diagnosis: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">MEDICINES & DOSAGES (Rx)</label>
                <textarea
                  rows={4}
                  value={rxForm.medicines}
                  onChange={(e) => setRxForm({ ...rxForm, medicines: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                />
              </div>

              <button
                onClick={() => {
                  alert("Digital e-Prescription generated & sent to patient's WhatsApp & ABHA Locker!");
                  setShowRxModal(false);
                }}
                className="w-full py-3 bg-gradient-to-r from-teal-400 to-cyan-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg"
              >
                Sign & Transmit Digital e-Prescription
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
