import React, { useState, useEffect } from 'react';
import { Download, Smartphone, CheckCircle, X, Share, PlusSquare, WifiOff, Sparkles, ShieldCheck } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [showBanner, setShowBanner] = useState<boolean>(true);
  const [isIOS, setIsIOS] = useState<boolean>(false);
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);

  useEffect(() => {
    // Detect iOS
    const ua = window.navigator.userAgent;
    const iosDevice = /iPad|iPhone|iPod/.test(ua) && !(window as any).MSStream;
    setIsIOS(iosDevice);

    // Check standalone mode
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true;
    
    if (isStandalone) {
      setIsInstalled(true);
    }

    // Capture beforeinstallprompt event for Android / Chrome / Desktop
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
      setShowBanner(false);
      setShowModal(false);
    };

    // Listen for online/offline events
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    // Custom trigger event from Navbar or Hero
    const handleCustomOpenInstall = () => {
      setShowModal(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('open-pwa-install', handleCustomOpenInstall);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('open-pwa-install', handleCustomOpenInstall);
    };
  }, []);


  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const choiceResult = await deferredPrompt.userChoice;
        if (choiceResult.outcome === 'accepted') {
          setIsInstalled(true);
          setShowBanner(false);
        }
        setDeferredPrompt(null);
      } catch (err) {
        console.warn('Install prompt error:', err);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      {/* Offline Warning Ribbon */}
      {isOffline && (
        <div className="bg-amber-500/90 text-slate-950 font-bold px-4 py-2 text-center text-xs flex items-center justify-center gap-2 shadow-lg backdrop-blur-md sticky top-0 z-[60]">
          <WifiOff className="w-4 h-4 animate-bounce" />
          <span>You are currently offline. MEDCLAN Emergency SOS & Cached Records are running in Offline Emergency Mode.</span>
        </div>
      )}

      {/* Floating Sticky Mobile Download Bar (Shows if not installed) */}
      {!isInstalled && showBanner && (
        <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 border-b border-teal-500/30 px-4 py-2.5 text-slate-200 text-xs sm:text-sm flex items-center justify-between shadow-2xl relative z-40">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-teal-500/20 rounded-xl border border-teal-500/40 text-teal-300 animate-pulse">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white flex items-center gap-1.5">
                Download MEDCLAN Mobile App
                <span className="bg-teal-500/20 text-teal-300 text-[10px] font-mono px-1.5 py-0.2 rounded border border-teal-500/30">
                  Android & iOS
                </span>
              </div>
              <p className="text-[11px] text-slate-300 hidden sm:block">
                Install for 1-Tap Emergency SOS, Offline Access & Instant Doctor Consultations.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleInstallClick}
              className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-slate-950 font-black px-3.5 py-1.5 rounded-xl shadow-lg shadow-teal-500/20 flex items-center gap-1.5 text-xs transition-all transform active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install App</span>
            </button>

            <button
              onClick={() => setShowBanner(false)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Close banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Mobile App Download Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden text-slate-100 animate-in fade-in zoom-in duration-200">
            
            {/* Background Glow */}
            <div className="absolute top-0 right-0 w-40 h-40 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white bg-slate-800/60 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-teal-400 to-cyan-500 p-0.5 flex items-center justify-center shadow-lg shadow-teal-500/30">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Smartphone className="w-6 h-6 text-teal-400" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-black text-white">Download MEDCLAN App</h3>
                <p className="text-xs text-teal-400 font-mono">Standalone PWA Mobile Experience</p>
              </div>
            </div>

            <p className="text-sm text-slate-300 mb-5 leading-relaxed">
              Install the MEDCLAN Mobile App directly onto your home screen for instant access to emergency SOS alerts, offline doctor search, and medical bill fraud detection.
            </p>

            {isIOS ? (
              <div className="bg-slate-950 border border-teal-500/30 rounded-2xl p-4 space-y-3 mb-6">
                <div className="text-xs font-bold text-teal-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <AppleIcon /> iOS Safari Installation Instructions:
                </div>
                <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside">
                  <li>Tap the <Share className="w-3.5 h-3.5 inline text-teal-400 mx-1" /> <strong>Share</strong> icon in Safari's bottom toolbar.</li>
                  <li>Scroll down the menu and tap <PlusSquare className="w-3.5 h-3.5 inline text-teal-400 mx-1" /> <strong>Add to Home Screen</strong>.</li>
                  <li>Confirm by tapping <strong>Add</strong> at the top right.</li>
                </ol>
              </div>
            ) : (
              <div className="bg-slate-950 border border-teal-500/30 rounded-2xl p-4 space-y-3 mb-6">
                <div className="text-xs font-bold text-teal-300 uppercase tracking-wider font-mono">
                  Android / Chrome Installation:
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Tap the button below or tap your browser's menu (⋮) and select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
                </p>
              </div>
            )}

            <div className="space-y-2">
              {deferredPrompt && (
                <button
                  onClick={handleInstallClick}
                  className="w-full bg-gradient-to-r from-teal-500 via-cyan-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black py-3 rounded-xl shadow-lg shadow-teal-500/30 flex items-center justify-center gap-2 transition-all transform active:scale-98"
                >
                  <Download className="w-4 h-4" />
                  Install App Now
                </button>
              )}

              <button
                onClick={() => setShowModal(false)}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl transition-colors text-xs"
              >
                Close & Continue in Browser
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-center text-[11px] text-slate-400 gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Verified Safe PWA • No App Store Account Needed</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

const AppleIcon = () => (
  <svg className="w-3.5 h-3.5 inline fill-current" viewBox="0 0 24 24">
    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 4.54c.66-.8 1.11-1.92.99-3.04-.96.04-2.12.64-2.8 1.44-.61.71-1.14 1.86-1 2.97 1.08.08 2.16-.57 2.81-1.37z" />
  </svg>
);
