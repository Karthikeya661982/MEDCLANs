import React, { useState } from 'react';
import { Stethoscope, Search, MapPin, Star, Video, Phone, Calendar, Clock, Filter, CheckCircle2, ChevronRight, User, MessageSquare, Home } from 'lucide-react';
import { Doctor, Appointment } from '../types';
import { MOCK_DOCTORS } from '../data/mockData';
import { InteractiveMap } from './InteractiveMap';

interface NearbyDoctorFinderProps {
  onBookAppointment: (appointment: Appointment) => void;
  onLaunchVideoConsultation?: (doc: Doctor) => void;
}

export const NearbyDoctorFinder: React.FC<NearbyDoctorFinderProps> = ({
  onBookAppointment,
  onLaunchVideoConsultation,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('All');
  const [availableNowOnly, setAvailableNowOnly] = useState(false);
  const [videoOnly, setVideoOnly] = useState(false);
  const [homeVisitOnly, setHomeVisitOnly] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  
  // Slot booking state
  const [selectedDate, setSelectedDate] = useState('Today');
  const [selectedSlot, setSelectedSlot] = useState('03:30 PM');
  const [consultationType, setConsultationType] = useState<'In-Person' | 'Video Call' | 'Home Visit'>('Video Call');
  const [homeAddress, setHomeAddress] = useState('Flat 402, Sunshine Heights, Road No. 36, Jubilee Hills, Hyderabad');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  const specialties = [
    'All',
    'Cardiologist',
    'Neurologist',
    'General Physician',
    'Pediatrician',
    'Orthopedic Surgeon',
    'Gynecologist',
  ];

  const filteredDoctors = MOCK_DOCTORS.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.hospitalName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSpecialty = selectedSpecialty === 'All' || doc.specialty === selectedSpecialty;
    const matchesAvailable = !availableNowOnly || doc.availableNow;
    const matchesVideo = !videoOnly || doc.videoCallAvailable;
    const matchesHomeVisit = !homeVisitOnly || doc.homeVisitAvailable;

    return matchesSearch && matchesSpecialty && matchesAvailable && matchesVideo && matchesHomeVisit;
  });

  const getEffectiveFee = (doc: Doctor, type: 'In-Person' | 'Video Call' | 'Home Visit') => {
    if (type === 'Home Visit') {
      return doc.homeVisitFeeINR || doc.feeINR + 300;
    }
    return doc.feeINR;
  };

  const handleConfirmBooking = () => {
    if (!selectedDoctor) return;

    const finalFee = getEffectiveFee(selectedDoctor, consultationType);

    const newAppointment: Appointment = {
      id: `apt-${Date.now()}`,
      doctorId: selectedDoctor.id,
      doctorName: selectedDoctor.name,
      doctorSpecialty: selectedDoctor.specialty,
      doctorImageUrl: selectedDoctor.imageUrl,
      patientName: "Karthikeya Sharma",
      date: selectedDate === 'Today' ? new Date().toISOString().split('T')[0] : '2026-07-24',
      timeSlot: selectedSlot,
      type: consultationType,
      status: 'CONFIRMED',
      feeINR: finalFee,
      homeAddress: consultationType === 'Home Visit' ? homeAddress : undefined,
      meetLink: consultationType === 'Video Call' ? `https://meet.medclan.ai/v/${selectedDoctor.id}` : undefined,
    };

    onBookAppointment(newAppointment);
    setBookingConfirmed(true);
    setTimeout(() => {
      setBookingConfirmed(false);
      setBookingModalOpen(false);
      setSelectedDoctor(null);
    }, 2500);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 bg-teal-500/10 text-teal-400 px-3 py-1 rounded-full text-xs font-bold border border-teal-500/30">
              <Stethoscope className="w-3.5 h-3.5" />
              <span>AI Doctor Recommendation & Booking Engine</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Find Nearby Verified Doctors & Home Visits
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Book clinic visits, 1-click HD video calls, or request doctors to visit your home directly with diagnostic medical kits.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs text-slate-300 bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
            <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
            <span><strong className="text-white">12 Doctors</strong> Available Nearby (Clinic, Video & Home Visit)</span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800/90 shadow-xl space-y-4 backdrop-blur-md">
        <div className="flex flex-col md:flex-row gap-3">
          
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by Doctor Name, Specialty or Hospital..."
              className="w-full bg-slate-950 border border-slate-800 text-white pl-10 pr-4 py-2.5 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-teal-500 transition-all placeholder:text-slate-500"
            />
          </div>

          {/* Quick Toggle Checks */}
          <div className="flex items-center space-x-2 overflow-x-auto">
            <button
              onClick={() => setAvailableNowOnly(!availableNowOnly)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all whitespace-nowrap ${
                availableNowOnly
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Available Now</span>
            </button>

            <button
              onClick={() => setVideoOnly(!videoOnly)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all whitespace-nowrap ${
                videoOnly
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Video Call</span>
            </button>

            <button
              onClick={() => setHomeVisitOnly(!homeVisitOnly)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all whitespace-nowrap ${
                homeVisitOnly
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <Home className="w-3.5 h-3.5" />
              <span>Home Visit</span>
            </button>
          </div>

        </div>

        {/* Specialty Filter Pills */}
        <div className="flex items-center space-x-2 overflow-x-auto pt-1 pb-1">
          {specialties.map((spec) => (
            <button
              key={spec}
              onClick={() => setSelectedSpecialty(spec)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedSpecialty === spec
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 font-bold shadow-md shadow-teal-500/20'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800/80'
              }`}
            >
              {spec}
            </button>
          ))}
        </div>
      </div>

      {/* Split View: Live Map & Doctor List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Interactive Map Visualizer */}
        <div className="lg:col-span-5 order-2 lg:order-1">
          <div className="sticky top-28 space-y-3">
            <h3 className="text-sm font-bold text-slate-300 flex items-center justify-between">
              <span>LIVE GPS DOCTOR LOCATOR</span>
              <span className="text-xs text-teal-400 font-mono">Hyderabad Metro</span>
            </h3>
            <InteractiveMap
              doctors={filteredDoctors}
              activeItemType="doctors"
              selectedId={selectedDoctor?.id}
              onSelectItem={(doc) => setSelectedDoctor(doc)}
              showRoute={!!selectedDoctor}
            />
          </div>
        </div>

        {/* Doctor Cards Directory List */}
        <div className="lg:col-span-7 order-1 lg:order-2 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Showing <strong className="text-white">{filteredDoctors.length} Doctors</strong></span>
            <span>Sorted by Distance & Rating</span>
          </div>

          <div className="space-y-4">
            {filteredDoctors.map((doc) => (
              <div
                key={doc.id}
                onClick={() => setSelectedDoctor(doc)}
                className={`p-5 rounded-3xl bg-slate-900/90 border transition-all duration-200 cursor-pointer ${
                  selectedDoctor?.id === doc.id
                    ? 'border-teal-500 shadow-2xl shadow-teal-500/10 bg-slate-900'
                    : 'border-slate-800/90 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  
                  {/* Doctor Info */}
                  <div className="flex items-start space-x-4">
                    <div className="relative">
                      <img
                        src={doc.imageUrl}
                        alt={doc.name}
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-700 shadow-md"
                      />
                      {doc.availableNow && (
                        <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-slate-900 rounded-full" title="Available Now" />
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-base font-bold text-white hover:text-teal-400 transition-colors">
                          {doc.name}
                        </h4>
                        <span className="text-[10px] font-bold bg-teal-500/10 text-teal-300 px-2 py-0.5 rounded border border-teal-500/20">
                          {doc.experienceYears} Yrs Exp
                        </span>
                      </div>

                      <p className="text-xs text-teal-400 font-semibold">{doc.specialty}</p>
                      
                      <p className="text-xs text-slate-400 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-500" />
                        {doc.hospitalName} • <span className="text-teal-300 font-medium">{doc.distanceKm} km away</span>
                      </p>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className="inline-flex items-center gap-1 text-xs text-amber-400 font-bold bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20">
                          <Star className="w-3 h-3 fill-amber-400" />
                          {doc.rating} ({doc.reviewsCount})
                        </span>

                        <span className="text-[11px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                          {doc.languages.join(', ')}
                        </span>

                        {doc.homeVisitAvailable && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-amber-300 font-semibold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                            <Home className="w-3 h-3 text-amber-400" />
                            Home Visit Available
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Pricing & Booking CTA */}
                  <div className="w-full sm:w-auto flex sm:flex-col items-center sm:items-end justify-between sm:justify-center pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                    <div className="text-left sm:text-right">
                      <span className="text-xs text-slate-400">Consultation Fee</span>
                      <div className="text-lg font-black text-white font-mono">₹{doc.feeINR}</div>
                      {doc.homeVisitAvailable && (
                        <div className="text-[10px] text-amber-400 font-medium">Home Visit: ₹{doc.homeVisitFeeINR || doc.feeINR + 300}</div>
                      )}
                    </div>

                    <div className="flex items-center space-x-2 mt-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedDoctor(doc);
                          setBookingModalOpen(true);
                        }}
                        className="px-4 py-2 bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-400 hover:to-cyan-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg shadow-teal-500/20 transition-all flex items-center space-x-1"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Book Slot</span>
                      </button>

                      {doc.videoCallAvailable && onLaunchVideoConsultation && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onLaunchVideoConsultation(doc);
                          }}
                          className="p-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-xl border border-slate-700"
                          title="Instant Video Call"
                        >
                          <Video className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Appointment Slot Booking Modal */}
      {bookingModalOpen && selectedDoctor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xl p-4 overflow-y-auto">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6 text-slate-100">
            
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <img src={selectedDoctor.imageUrl} className="w-12 h-12 rounded-xl object-cover" />
                <div>
                  <h3 className="text-base font-bold text-white">{selectedDoctor.name}</h3>
                  <p className="text-xs text-teal-400 font-medium">{selectedDoctor.specialty} • {selectedDoctor.hospitalName}</p>
                </div>
              </div>
              <button
                onClick={() => setBookingModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                ✕
              </button>
            </div>

            {bookingConfirmed ? (
              <div className="py-8 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-xl font-bold text-white">Appointment Confirmed!</h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {consultationType === 'Home Visit' ? (
                    <span>
                      🏡 <strong>Doctor Home Visit Booked!</strong> {selectedDoctor.name} will visit your residence at <span className="text-amber-300 font-bold">{homeAddress}</span> on <strong className="text-white">{selectedDate}</strong> at <strong className="text-white">{selectedSlot}</strong>. Live Doctor Location tracking link and SMS dispatched to your phone.
                    </span>
                  ) : (
                    <span>
                      Your appointment with {selectedDoctor.name} for {selectedDate} at {selectedSlot} ({consultationType}) is booked. Instant SMS details sent to your registered mobile.
                    </span>
                  )}
                </p>
              </div>
            ) : (
              <div className="space-y-5">
                
                {/* Consultation Type Selector */}
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">CHOOSE CONSULTATION MODE</label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setConsultationType('Video Call')}
                      className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                        consultationType === 'Video Call'
                          ? 'bg-teal-500 text-slate-950 border-teal-400 shadow-md shadow-teal-500/20'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      <Video className="w-4 h-4" />
                      <span>HD Video Call</span>
                      <span className="text-[10px] font-normal opacity-80">Online</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setConsultationType('In-Person')}
                      className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                        consultationType === 'In-Person'
                          ? 'bg-teal-500 text-slate-950 border-teal-400 shadow-md shadow-teal-500/20'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      <User className="w-4 h-4" />
                      <span>In-Person</span>
                      <span className="text-[10px] font-normal opacity-80">At Hospital</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setConsultationType('Home Visit')}
                      className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center space-y-1 transition-all ${
                        consultationType === 'Home Visit'
                          ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md shadow-amber-400/20'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      <Home className="w-4 h-4" />
                      <span>Doctor Visit Home</span>
                      <span className="text-[10px] font-normal opacity-80">At Your Doorstep</span>
                    </button>
                  </div>
                </div>

                {/* Home Visit Address Details Input */}
                {consultationType === 'Home Visit' && (
                  <div className="p-3.5 bg-amber-500/10 rounded-2xl border border-amber-500/30 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-amber-300 font-bold">
                      <span className="flex items-center gap-1.5">
                        <Home className="w-4 h-4 text-amber-400" />
                        Patient Residence Visit Address
                      </span>
                      <span className="text-[10px] bg-amber-400/20 text-amber-200 px-2 py-0.5 rounded font-mono">
                        Medical Kit Included
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-tight">
                      {selectedDoctor.name} will visit your address with diagnostic equipment (BP apparatus, Portable ECG, Pulse Oximeter, & Emergency Medicines).
                    </p>
                    <div className="pt-1">
                      <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                        Confirm Home Address:
                      </label>
                      <input
                        type="text"
                        value={homeAddress}
                        onChange={(e) => setHomeAddress(e.target.value)}
                        placeholder="Enter house no, street, locality, landmark..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>
                )}

                {/* Date Selection */}
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">SELECT DATE</label>
                  <div className="flex gap-2">
                    {['Today', 'Tomorrow', '25 Jul', '26 Jul'].map((d) => (
                      <button
                        key={d}
                        onClick={() => setSelectedDate(d)}
                        className={`flex-1 py-2 rounded-xl text-xs font-semibold ${
                          selectedDate === d
                            ? 'bg-slate-800 text-teal-400 border border-teal-500/50'
                            : 'bg-slate-950 text-slate-400 border border-slate-800'
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Slot Selection */}
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-2">AVAILABLE TIME SLOTS</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['02:30 PM', '03:15 PM', '03:30 PM', '04:00 PM', '05:30 PM', '06:15 PM'].map((s) => (
                      <button
                        key={s}
                        onClick={() => setSelectedSlot(s)}
                        className={`py-2 rounded-xl text-xs font-mono font-bold ${
                          selectedSlot === s
                            ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow-md'
                            : 'bg-slate-950 text-slate-300 border border-slate-800'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Total Summary */}
                <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    Total Fee ({consultationType}):
                    {consultationType === 'Home Visit' && (
                      <span className="text-[10px] text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded">Includes Visit & Travel</span>
                    )}
                  </span>
                  <span className="text-lg font-black text-white font-mono">
                    ₹{getEffectiveFee(selectedDoctor, consultationType)}
                  </span>
                </div>

                {/* Confirm Button */}
                <button
                  onClick={handleConfirmBooking}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-teal-400 via-teal-500 to-cyan-500 text-slate-950 font-black text-sm shadow-xl shadow-teal-500/25 hover:scale-[1.02] transition-all"
                >
                  Confirm Appointment & Pay ₹{getEffectiveFee(selectedDoctor, consultationType)}
                </button>

              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};

