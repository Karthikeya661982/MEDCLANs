import React, { useState } from 'react';
import { Activity, ShieldAlert, Stethoscope, FileSearch, Calculator, Landmark, Bot, User, Moon, Sun, Globe, Menu, X, ChevronDown, Sparkles } from 'lucide-react';
import { Language, UserRole } from '../types';

interface NavbarProps {
  currentTab?: string;
  activeTab?: string;
  setCurrentTab?: (tab: string) => void;
  onTabChange?: (tab: string) => void;
  language?: Language;
  currentLanguage?: Language;
  setLanguage?: (lang: Language) => void;
  onLanguageChange?: (lang: Language) => void;
  isDarkMode?: boolean;
  setIsDarkMode?: (dark: boolean) => void;
  userRole?: UserRole;
  currentRole?: UserRole;
  setUserRole?: (role: UserRole) => void;
  onRoleChange?: (role: UserRole) => void;
  onTriggerSOS: () => void;
  onInstallApp?: () => void;
}


export const Navbar: React.FC<NavbarProps> = (props) => {
  const currentTab = props.activeTab ?? props.currentTab ?? 'home';
  const setCurrentTab = props.onTabChange ?? props.setCurrentTab ?? (() => {});
  const language = props.currentLanguage ?? props.language ?? 'en';
  const setLanguage = props.onLanguageChange ?? props.setLanguage ?? (() => {});
  const userRole = props.currentRole ?? props.userRole ?? 'patient';
  const setUserRole = props.onRoleChange ?? props.setUserRole ?? (() => {});
  const isDarkMode = props.isDarkMode ?? true;
  const setIsDarkMode = props.setIsDarkMode ?? (() => {});
  const onTriggerSOS = props.onTriggerSOS;
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const languages: { code: Language; label: string; native: string }[] = [
    { code: 'en', label: 'English', native: 'English' },
    { code: 'hi', label: 'Hindi', native: 'हिंदी' },
    { code: 'te', label: 'Telugu', native: 'తెలుగు' },
    { code: 'ta', label: 'Tamil', native: 'தமிழ்' },
    { code: 'kn', label: 'Kannada', native: 'కన్నడ' },
    { code: 'ml', label: 'Malayalam', native: 'మలయాళం' },
  ];

  const navItems = [
    { id: 'home', label: 'Home', icon: Activity },
    { id: 'doctors', label: 'Find Doctor', icon: Stethoscope },
    { id: 'sos', label: 'Emergency SOS', icon: ShieldAlert, highlight: true },
    { id: 'fraud', label: 'Bill Fraud Audit', icon: FileSearch },
    { id: 'estimator', label: 'Cost Estimator', icon: Calculator },
    { id: 'schemes', label: 'Govt Schemes', icon: Landmark },
    { id: 'chatbot', label: 'AI Assistant', icon: Bot },
    { id: 'dashboard', label: 'Dashboard', icon: User },
  ];

  const currentLangLabel = languages.find((l) => l.code === language)?.native || 'English';

  return (
    <header className="sticky top-0 z-50 w-full transition-all duration-300 backdrop-blur-xl bg-slate-950/80 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Brand Logo */}
        <div
          onClick={() => setCurrentTab('home')}
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="relative flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-br from-teal-400 via-cyan-500 to-emerald-600 p-0.5 shadow-lg shadow-teal-500/25 group-hover:scale-105 transition-all">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Activity className="w-6 h-6 text-teal-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xl font-black tracking-tight text-white font-mono">MED</span>
              <span className="text-xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-cyan-400 font-mono">CLAN</span>
              <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/30">
                PRO
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium tracking-wide">
              Saving Lives Faster & Smarter
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center space-x-1 bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800/80">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.id === 'sos') {
                    onTriggerSOS();
                  } else {
                    setCurrentTab(item.id);
                  }
                }}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                  item.highlight
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30 animate-pulse'
                    : isActive
                    ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Actions (SOS Button, Lang Picker, Role Toggle, Theme Switcher) */}
        <div className="hidden lg:flex items-center space-x-3">
          
          {/* Emergency SOS Pulse Button */}
          <button
            onClick={onTriggerSOS}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs tracking-wide shadow-xl shadow-rose-600/30 border border-rose-400/30 transform hover:scale-105 transition-all animate-bounce"
          >
            <ShieldAlert className="w-4 h-4 text-white" />
            <span>EMERGENCY SOS</span>
          </button>

          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setLangDropdownOpen(!langDropdownOpen)}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-800 transition-all"
            >
              <Globe className="w-4 h-4 text-teal-400" />
              <span>{currentLangLabel}</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>

            {langDropdownOpen && (
              <div className="absolute right-0 mt-2 w-40 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLanguage(l.code);
                      setLangDropdownOpen(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${
                      language === l.code ? 'text-teal-400 font-bold bg-teal-500/10' : 'text-slate-300'
                    }`}
                  >
                    <span>{l.label}</span>
                    <span className="text-[10px] text-slate-500">{l.native}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Role Toggle Selector */}
          <div className="relative">
            <button
              onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 text-xs font-semibold border border-teal-500/30 transition-all"
            >
              <User className="w-4 h-4 text-teal-400" />
              <span className="capitalize">{userRole} Portal</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>

            {roleDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2">
                {(['patient', 'doctor', 'admin'] as UserRole[]).map((role) => (
                  <button
                    key={role}
                    onClick={() => {
                      setUserRole(role);
                      setCurrentTab('dashboard');
                      setRoleDropdownOpen(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${
                      userRole === role ? 'text-teal-400 font-bold bg-teal-500/10' : 'text-slate-300'
                    }`}
                  >
                    <span className="capitalize">{role} Dashboard</span>
                    {userRole === role && <Sparkles className="w-3 h-3 text-teal-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-all"
            title="Toggle Dark/Light Mode"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>

        {/* Mobile Hamburger Toggle Button */}
        <div className="flex lg:hidden items-center space-x-2">
          <button
            onClick={onTriggerSOS}
            className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-black text-xs shadow-md shadow-rose-600/30 animate-pulse"
          >
            SOS
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-slate-900 text-slate-300 border border-slate-800"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

      </div>

      {/* Mobile Fullscreen Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-950/98 border-b border-slate-800 px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-4">
          <div className="grid grid-cols-2 gap-2">

            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    if (item.id === 'sos') {
                      onTriggerSOS();
                    } else {
                      setCurrentTab(item.id);
                    }
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 p-3 rounded-xl text-xs font-semibold ${
                    currentTab === item.id
                      ? 'bg-teal-500 text-slate-950 font-bold'
                      : 'bg-slate-900 text-slate-300 border border-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 text-teal-400" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <span className="font-medium">Switch Role:</span>
            <div className="flex space-x-1">
              {(['patient', 'doctor', 'admin'] as UserRole[]).map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    setUserRole(r);
                    setCurrentTab('dashboard');
                    setMobileMenuOpen(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs capitalize ${
                    userRole === r ? 'bg-teal-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
