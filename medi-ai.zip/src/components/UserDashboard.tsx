import React, { useState } from 'react';
import { User, Activity, Calendar, Clock, Pill, ShieldCheck, QrCode, Heart, Droplets, Moon, Scale, ArrowUpRight, CheckCircle2, Phone, Plus, Home, HardDrive } from 'lucide-react';
import { Appointment, UserHealthProfile } from '../types';
import { OfflineHealthRecordsManager } from './OfflineHealthRecordsManager';

interface UserDashboardProps {
  userProfile: UserHealthProfile;
  appointments: Appointment[];
  onNavigate: (tab: string) => void;
  onLaunchVideoConsultation?: (appointment: Appointment) => void;
  onProfileUpdated?: (updatedProfile: UserHealthProfile) => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  userProfile,
  appointments,
  onNavigate,
  onLaunchVideoConsultation,
  onProfileUpdated,
}) => {
  const [waterMl, setWaterMl] = useState(userProfile.dailyWaterMl);
  const [showQrModal, setShowQrModal] = useState(false);
  const [reminders, setReminders] = useState([
    { id: 'r1', name: 'Atorvastatin 10mg', time: '09:00 PM', taken: true },
    { id: 'r2', name: 'Pantoprazole 40mg', time: '08:00 AM', taken: false },
    { id: 'r3', name: 'Multivitamin Complex', time: '02:00 PM', taken: true },
  ]);

  const toggleReminder = (id: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, taken: !r.taken } : r))
    );
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-400 to-cyan-500 p-0.5 shadow-xl">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center font-black text-2xl text-teal-400 font-mono">
              KS
            </div>
          </div>
          <div>
            <h2 className="text-2xl font-black text-white flex items-center gap-2">
              Welcome back, {userProfile.name}
              <span className="text-xs bg-teal-500/10 text-teal-300 font-bold px-2.5 py-0.5 rounded border border-teal-500/20">
                ABHA ID Verified
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Age: {userProfile.age} • Blood Group: <strong className="text-rose-400">{userProfile.bloodGroup}</strong> • Insurance: {userProfile.insuranceProvider}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowQrModal(true)}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 font-bold text-xs rounded-xl border border-slate-800 flex items-center gap-2"
          >
            <QrCode className="w-4 h-4 text-teal-400" />
            Emergency QR ID
          </button>

          <button
            onClick={() => onNavigate('doctors')}
            className="px-4 py-2.5 bg-gradient-to-r from-teal-400 to-cyan-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg"
          >
            Book New Appointment
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        {/* Health Score */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>HEALTH SCORE</span>
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500/20" />
          </div>
          <div className="text-3xl font-black text-white font-mono">{userProfile.healthScore}/100</div>
          <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">Optimal Baseline</span>
        </div>

        {/* BMI */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>BMI CALCULATOR</span>
            <Scale className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-black text-white font-mono">{userProfile.bmi}</div>
          <span className="text-[10px] text-teal-300 font-bold">Normal Healthy Range</span>
        </div>

        {/* Water Tracker */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>WATER INTAKE</span>
            <Droplets className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{waterMl} / {userProfile.dailyWaterGoalMl} ml</div>
          <button
            onClick={() => setWaterMl((prev) => Math.min(prev + 250, 4000))}
            className="text-[10px] font-bold text-teal-400 bg-teal-500/10 hover:bg-teal-500/20 px-2 py-0.5 rounded border border-teal-500/30 flex items-center gap-1"
          >
            <Plus className="w-3 h-3" /> Add 250ml Glass
          </button>
        </div>

        {/* Sleep Tracker */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>SLEEP SCORE</span>
            <Moon className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-3xl font-black text-white font-mono">{userProfile.dailySleepHours} hrs</div>
          <span className="text-[10px] text-indigo-300 font-bold">Deep Sleep 2.5 hrs</span>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Appointments Queue */}
        <div className="lg:col-span-7 bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-teal-400" />
              Upcoming Medical Consultations ({appointments.length})
            </h3>
            <button onClick={() => onNavigate('doctors')} className="text-xs text-teal-400 font-bold hover:underline">
              Book Doctor
            </button>
          </div>

          <div className="space-y-3">
            {appointments.length > 0 ? (
              appointments.map((apt) => (
                <div key={apt.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center space-x-3">
                    <img src={apt.doctorImageUrl} className="w-12 h-12 rounded-xl object-cover" />
                    <div>
                      <h4 className="text-sm font-bold text-white">{apt.doctorName}</h4>
                      <div className="flex items-center space-x-2">
                        <p className="text-xs text-teal-400 font-medium">{apt.doctorSpecialty}</p>
                        {apt.type === 'Home Visit' ? (
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded border border-amber-500/30 flex items-center gap-1">
                            <Home className="w-3 h-3" /> Home Visit
                          </span>
                        ) : (
                          <span className="text-[10px] bg-slate-800 text-slate-300 font-medium px-2 py-0.5 rounded">
                            {apt.type}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{apt.date} at {apt.timeSlot}</p>
                      {apt.homeAddress && (
                        <p className="text-[11px] text-amber-300/90 font-mono mt-0.5">
                          📍 Address: {apt.homeAddress}
                        </p>
                      )}
                    </div>
                  </div>

                  {apt.type === 'Video Call' && (
                    <button
                      onClick={() => onLaunchVideoConsultation?.(apt)}
                      className="px-3.5 py-2 bg-gradient-to-r from-teal-400 to-cyan-500 text-slate-950 font-bold text-xs rounded-xl shadow whitespace-nowrap"
                    >
                      Join Video Call
                    </button>
                  )}

                  {apt.type === 'Home Visit' && (
                    <div className="text-right">
                      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/30 inline-block">
                        Doctor En Route
                      </span>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400 text-center py-6">No upcoming appointments scheduled.</p>
            )}
          </div>
        </div>

        {/* Medicine Reminders & Emergency Contacts */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Daily Medicine Reminders */}
          <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Pill className="w-4 h-4 text-teal-400" />
              Daily Medicine Reminders
            </h3>

            <div className="space-y-2">
              {reminders.map((r) => (
                <div
                  key={r.id}
                  onClick={() => toggleReminder(r.id)}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                    r.taken ? 'bg-slate-950 border-slate-800/60 opacity-60' : 'bg-slate-950 border-teal-500/40 text-white'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-4 h-4 rounded-md border flex items-center justify-center ${r.taken ? 'bg-emerald-500 border-emerald-500 text-slate-950' : 'border-slate-600'}`}>
                      {r.taken && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                    <span className={`text-xs font-bold ${r.taken ? 'line-through text-slate-500' : 'text-white'}`}>{r.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">{r.time}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Emergency Contacts */}
          <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Phone className="w-4 h-4 text-rose-500" />
              Saved Emergency Family Contacts
            </h3>

            <div className="space-y-2">
              {userProfile.emergencyContacts.map((c, idx) => (
                <div key={idx} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <strong className="text-white block">{c.name} ({c.relation})</strong>
                    <span className="text-slate-400 font-mono text-[11px]">{c.phone}</span>
                  </div>
                  <a href={`tel:${c.phone}`} className="p-2 bg-rose-600/20 text-rose-400 rounded-lg">
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* Persistent IndexedDB Offline Storage Section */}
      <OfflineHealthRecordsManager
        userProfile={userProfile}
        onProfileUpdated={onProfileUpdated || (() => {})}
      />

      {/* Emergency QR Code Medical Profile Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xl p-4">
          <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white">Emergency Medical QR Card</h3>
              <button onClick={() => setShowQrModal(false)} className="text-slate-400">✕</button>
            </div>

            <div className="p-6 bg-white rounded-2xl inline-block shadow-xl">
              {/* Simulated QR Code SVG */}
              <div className="w-40 h-40 bg-slate-950 rounded-xl flex items-center justify-center text-teal-400 p-2 font-mono text-[10px] leading-tight text-center">
                ABHA ID: {userProfile.ayushmanId}
                <br />
                BLOOD: {userProfile.bloodGroup}
                <br />
                ALLERGIES: Penicillin
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-1">
              <p className="font-bold text-white">{userProfile.name}</p>
              <p className="text-slate-400">Emergency Responders can scan this code on lockscreen to view blood type & allergies.</p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
