import React, { useState } from 'react';
import { Building2, ShieldCheck, MapPin, Star, Phone, CheckCircle2, AlertTriangle, ArrowUpRight, Crosshair, HeartPulse, Filter } from 'lucide-react';
import { Hospital } from '../types';
import { MOCK_HOSPITALS } from '../data/mockData';
import { InteractiveMap } from './InteractiveMap';

export const HospitalComparator: React.FC = () => {
  const [selectedGrade, setSelectedGrade] = useState('All');
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);

  const grades = ['All', 'Super Specialty', 'Government', 'Multi Specialty'];

  const filteredHospitals = MOCK_HOSPITALS.filter(
    (h) => selectedGrade === 'All' || h.grade === selectedGrade
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/30 to-slate-950 p-6 sm:p-8 rounded-3xl border border-emerald-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full text-xs font-bold border border-emerald-500/30">
              <Building2 className="w-3.5 h-3.5" />
              <span>AI Hospital Price & Success Rate Comparison Matrix</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Affordable Hospital Recommendation
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Compare nearby hospitals side-by-side on live ICU bed availability, surgery success rates, cashless insurance networks, government scheme approvals, and average treatment charges.
            </p>
          </div>

          <div className="flex items-center space-x-2 overflow-x-auto">
            {grades.map((g) => (
              <button
                key={g}
                onClick={() => setSelectedGrade(g)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  selectedGrade === g
                    ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20'
                    : 'bg-slate-950 text-slate-400 border border-slate-800'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Map Preview */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">MAP VIEW OF NEARBY HOSPITALS & EMERGENCY ROOMS</h3>
        <InteractiveMap
          hospitals={filteredHospitals}
          activeItemType="hospitals"
          selectedId={selectedHospital?.id}
          onSelectItem={(hosp) => setSelectedHospital(hosp)}
        />
      </div>

      {/* Side by Side Comparison Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredHospitals.map((hosp) => (
          <div
            key={hosp.id}
            onClick={() => setSelectedHospital(hosp)}
            className={`p-6 rounded-3xl bg-slate-900/90 border transition-all duration-300 cursor-pointer ${
              selectedHospital?.id === hosp.id
                ? 'border-emerald-500 shadow-2xl shadow-emerald-500/10 bg-slate-900'
                : 'border-slate-800/90 hover:border-slate-700'
            }`}
          >
            <div className="space-y-4">
              
              {/* Top Banner */}
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <h4 className="text-base font-bold text-white">{hosp.name}</h4>
                    <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                      {hosp.grade}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    {hosp.address} • <strong className="text-teal-400">{hosp.distanceKm} km away</strong>
                  </p>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-xs font-black text-amber-400 flex items-center gap-1 bg-amber-400/10 px-2.5 py-1 rounded-lg border border-amber-400/20">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    {hosp.rating} Rating
                  </div>
                </div>
              </div>

              {/* Key Metrics Grid */}
              <div className="grid grid-cols-3 gap-2 py-3 bg-slate-950 rounded-2xl border border-slate-800 text-center">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">ICU BEDS</span>
                  <span className="text-sm font-black text-emerald-400 font-mono">{hosp.icuBedsAvailable}/{hosp.totalIcuBeds}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">SUCCESS RATE</span>
                  <span className="text-sm font-black text-cyan-400 font-mono">{hosp.successRatePercent}%</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">EMERGENCY WAIT</span>
                  <span className="text-xs font-bold text-teal-300">{hosp.emergencyRoomStatus}</span>
                </div>
              </div>

              {/* Pricing & Insurance Accepted */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-300">
                  <span>Avg Angioplasty Cost:</span>
                  <strong className="text-white font-mono">{hosp.avgCostAngioplastyINR === 0 ? "100% Free under Scheme" : `₹${hosp.avgCostAngioplastyINR.toLocaleString()}`}</strong>
                </div>

                <div className="flex items-center justify-between text-slate-300">
                  <span>Avg Delivery Cost:</span>
                  <strong className="text-white font-mono">{hosp.avgCostNormalDeliveryINR === 0 ? "100% Free under Scheme" : `₹${hosp.avgCostNormalDeliveryINR.toLocaleString()}`}</strong>
                </div>

                <div className="pt-2">
                  <span className="text-[11px] text-slate-400 font-bold block mb-1">CASHLESS INSURANCE ACCEPTED:</span>
                  <div className="flex flex-wrap gap-1">
                    {hosp.cashlessInsuranceAccepted.map((ins, i) => (
                      <span key={i} className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                        {ins}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-1">
                  <span className="text-[11px] text-slate-400 font-bold block mb-1">GOVT SCHEMES APPROVED:</span>
                  <div className="flex flex-wrap gap-1">
                    {hosp.govtSchemesAccepted.map((sch, i) => (
                      <span key={i} className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 font-medium">
                        {sch}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Call ER Action */}
              <div className="pt-3 flex gap-2">
                <a
                  href={`tel:${hosp.phone}`}
                  className="flex-1 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-xs rounded-xl shadow-md text-center flex items-center justify-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  Call Emergency Room ({hosp.phone})
                </a>
              </div>

            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
