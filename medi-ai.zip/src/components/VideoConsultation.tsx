import React, { useState } from 'react';
import { Video, Mic, MicOff, VideoOff, PhoneOff, MessageSquare, Send, FileText, Sparkles, User, ShieldCheck } from 'lucide-react';

interface VideoConsultationProps {
  doctorName?: string;
  doctorSpecialty?: string;
  doctorImageUrl?: string;
  onEndCall: () => void;
}

export const VideoConsultation: React.FC<VideoConsultationProps> = ({
  doctorName = "Dr. Arvind Swaminathan",
  doctorSpecialty = "Cardiologist",
  doctorImageUrl = "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=300",
  onEndCall,
}) => {
  const [micOn, setMicOn] = useState(true);
  const [cameraOn, setCameraOn] = useState(true);
  const [messages, setMessages] = useState([
    { sender: 'Dr. Arvind', text: 'Hello Karthikeya! I am reviewing your ECG report now.' },
  ]);
  const [chatInput, setChatInput] = useState('');

  const handleSendChat = () => {
    if (!chatInput.trim()) return;
    setMessages((prev) => [...prev, { sender: 'You', text: chatInput }]);
    setChatInput('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col p-4 sm:p-6 overflow-hidden">
      
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <img src={doctorImageUrl} className="w-10 h-10 rounded-xl object-cover border border-teal-500" />
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              {doctorName}
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </h3>
            <p className="text-xs text-teal-400">{doctorSpecialty} • Encrypted Telehealth Call</p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span className="bg-slate-900 px-3 py-1 rounded-full border border-slate-800 font-mono text-emerald-400">
            08:24 MINS
          </span>
          <button onClick={onEndCall} className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs">
            End Call
          </button>
        </div>
      </div>

      {/* Main Grid View */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 my-4 overflow-hidden">
        
        {/* Video Viewport Area */}
        <div className="lg:col-span-8 bg-slate-900 rounded-3xl border border-slate-800 relative overflow-hidden flex items-center justify-center">
          
          {/* Main Doctor Stream (Simulated UI) */}
          <img
            src={doctorImageUrl}
            className={`w-full h-full object-cover ${!cameraOn ? 'filter blur-md' : ''}`}
          />

          {/* Overlay Gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80 pointer-events-none" />

          {/* Doctor Name Overlay */}
          <div className="absolute bottom-6 left-6 z-10 space-y-1">
            <span className="text-xs font-bold bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-full text-white border border-slate-800">
              {doctorName} (HD Video)
            </span>
          </div>

          {/* Self Camera PIP Thumbnail */}
          <div className="absolute top-6 right-6 w-36 h-48 bg-slate-950 rounded-2xl border-2 border-slate-700 shadow-2xl overflow-hidden flex items-center justify-center">
            <div className="text-center p-2 space-y-1">
              <User className="w-8 h-8 text-teal-400 mx-auto" />
              <span className="text-[10px] text-slate-300 font-bold block">You (Karthikeya)</span>
            </div>
          </div>

          {/* AI Clinical Scribe Realtime Subtitles */}
          <div className="absolute bottom-6 right-6 max-w-sm bg-slate-950/90 backdrop-blur-xl p-3 rounded-2xl border border-teal-500/30 text-xs text-slate-200 shadow-2xl">
            <span className="text-[10px] text-teal-400 font-bold flex items-center gap-1 mb-0.5">
              <Sparkles className="w-3 h-3" /> AI LIVE CLINICAL SCRIBE
            </span>
            <p className="text-[11px] font-mono text-slate-300">
              "...your blood pressure readings are stable. Continue Atorvastatin for 30 days."
            </p>
          </div>

        </div>

        {/* Side Chat & Notes View */}
        <div className="lg:col-span-4 bg-slate-900 rounded-3xl border border-slate-800 flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-800">
            <h4 className="text-xs font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-teal-400" />
              Consultation Live Chat
            </h4>
          </div>

          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`p-3 rounded-2xl text-xs ${m.sender === 'You' ? 'bg-teal-500 text-slate-950 font-semibold ml-auto max-w-[80%]' : 'bg-slate-950 text-slate-200 border border-slate-800 mr-auto max-w-[80%]'}`}>
                <span className="text-[9px] opacity-70 block mb-0.5 font-bold">{m.sender}</span>
                <p>{m.text}</p>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
              placeholder="Type message to doctor..."
              className="flex-1 bg-slate-900 border border-slate-800 text-white px-3 py-2 rounded-xl text-xs focus:outline-none"
            />
            <button onClick={handleSendChat} className="p-2 bg-teal-400 text-slate-950 rounded-xl font-bold">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Bottom Floating Control Bar */}
      <div className="flex items-center justify-center space-x-4 pt-2">
        <button
          onClick={() => setMicOn(!micOn)}
          className={`p-4 rounded-2xl border transition-all ${
            micOn ? 'bg-slate-900 text-white border-slate-700' : 'bg-rose-600 text-white border-rose-500'
          }`}
        >
          {micOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>

        <button
          onClick={() => setCameraOn(!cameraOn)}
          className={`p-4 rounded-2xl border transition-all ${
            cameraOn ? 'bg-slate-900 text-white border-slate-700' : 'bg-rose-600 text-white border-rose-500'
          }`}
        >
          {cameraOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
        </button>

        <button
          onClick={onEndCall}
          className="p-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold shadow-xl shadow-rose-600/40"
        >
          <PhoneOff className="w-6 h-6" />
        </button>
      </div>

    </div>
  );
};
