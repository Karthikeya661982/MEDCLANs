import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User, Sparkles, Mic, MicOff, Volume2, Image as ImageIcon, ShieldAlert, ArrowRight, RefreshCw, X } from 'lucide-react';
import { Language } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  image?: string;
  suggestions?: string[];
  timestamp: string;
}

interface AIChatbotProps {
  language: Language;
  onNavigate: (tab: string) => void;
  onTriggerSOS: () => void;
}

export const AIChatbot: React.FC<AIChatbotProps> = ({
  language,
  onNavigate,
  onTriggerSOS,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'ai',
      text: 'Hello! I am MEDCLAN AI, your emergency response & healthcare assistant. How can I assist you today?',
      suggestions: [
        'Find nearby emergency doctors',
        'Estimate treatment cost',
        'Check government schemes',
        'Trigger Emergency SOS',
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() && !selectedImage) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      image: selectedImage || undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    const currentImg = selectedImage;
    setSelectedImage(null);
    setLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          language,
          imageBase64: currentImg,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();

      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: data.reply || 'I am here to support your medical queries. Please seek immediate local emergency care if symptoms are severe.',
        suggestions: data.suggestions || ['Find nearby doctors', 'Estimate cost'],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);

      // Speech synthesis
      if ('speechSynthesis' in window && data.reply) {
        const utterance = new SpeechSynthesisUtterance(data.reply.slice(0, 180));
        window.speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.warn('Chat AI API unavailable, switching to Offline AI Medical Triage:', error);

      // Smart Offline AI Response Generator
      const offlineResult = getOfflineResponse(textToSend);
      const aiMsg: Message = {
        id: `ai-off-${Date.now()}`,
        sender: 'ai',
        text: offlineResult.reply,
        suggestions: offlineResult.suggestions,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);

      if ('speechSynthesis' in window && offlineResult.reply) {
        const utterance = new SpeechSynthesisUtterance(offlineResult.reply.slice(0, 180));
        window.speechSynthesis.speak(utterance);
      }
    } finally {
      setLoading(false);
    }
  };

  const getOfflineResponse = (query: string) => {
    const q = query.toLowerCase();
    if (q.includes('chest pain') || q.includes('heart') || q.includes('stroke') || q.includes('emergency')) {
      return {
        reply: "🚨 CRITICAL MEDICAL ALERT: Chest pain or severe distress requires IMMEDIATE EMERGENCY RESPONSE. Please tap the red Emergency SOS button or dial 108 / 911.\n\nFirst-Aid Instructions:\n1. Sit in a comfortable semi-recumbent position.\n2. Loosen tight clothing around neck and waist.\n3. Take Aspirin 325mg if recommended by physician.\n4. Keep doors unlocked for ambulance paramedics.",
        suggestions: ["Trigger Emergency SOS", "Find nearest ER hospital", "Call 108 Ambulance"]
      };
    } else if (q.includes('fever') || q.includes('cough') || q.includes('cold') || q.includes('headache')) {
      return {
        reply: "🌡️ [Offline Medical Triage]: For fever or headache symptoms:\n\n1. Hydration: Drink ORS, coconut water, or warm soups.\n2. Medication: Paracetamol 500mg/650mg after food every 6 hours if temperature exceeds 100°F.\n3. Rest: Ensure 8+ hours of uninterrupted rest.\n\n⚠️ Consult a doctor immediately if fever lasts > 3 days.",
        suggestions: ["Book Online Video Consultation", "Find nearby General Physician", "Estimate Medication Cost"]
      };
    } else if (q.includes('cost') || q.includes('price') || q.includes('estimate') || q.includes('bill')) {
      return {
        reply: "💰 [Offline Cost Guide]: MEDCLAN provides standardized government tariff guidelines:\n\n• General Ward Bed: ₹1,500 - ₹3,000 / day\n• ICU Bed Charge: ₹6,000 - ₹12,000 / day\n• Cardiac Angioplasty: ₹1,20,000 - ₹1,80,000\n• Cataract Surgery: ₹18,000 - ₹35,000 per eye\n\nUse our Bill Fraud Forensic Auditor tab to upload bills and audit overcharges!",
        suggestions: ["Open Bill Fraud Auditor", "Compare Hospital Costs", "Check Ayushman Bharat Eligibility"]
      };
    } else {
      return {
        reply: `[MEDCLAN Offline AI Medical Assistant]: Operating in 100% Offline Medical Emergency Mode.\n\nI can assist you with local doctor directories, emergency first aid protocols, surgical cost estimates, or hospital bill audit checks without internet connection.`,
        suggestions: ["Find nearby doctors", "Estimate treatment cost", "Trigger Emergency SOS", "Check government schemes"]
      };
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSuggestionClick = (sugg: string) => {
    if (sugg.toLowerCase().includes('doctor')) {
      onNavigate('doctors');
    } else if (sugg.toLowerCase().includes('cost') || sugg.toLowerCase().includes('estimate')) {
      onNavigate('estimator');
    } else if (sugg.toLowerCase().includes('scheme')) {
      onNavigate('schemes');
    } else if (sugg.toLowerCase().includes('sos') || sugg.toLowerCase().includes('emergency')) {
      onTriggerSOS();
    } else {
      handleSend(sugg);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/40 to-slate-950 p-6 rounded-3xl border border-teal-500/30 flex items-center justify-between shadow-xl">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
            <Bot className="w-7 h-7 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              MEDCLAN Clinical Assistant
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/20">
                Active 24x7
              </span>
            </h2>
            <p className="text-xs text-slate-300">Supports Voice, Text & Image Uploads in 6 Languages</p>
          </div>
        </div>

        <button
          onClick={onTriggerSOS}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-rose-600/30 animate-pulse"
        >
          Emergency SOS
        </button>
      </div>

      {/* Chat Window */}
      <div className="bg-slate-900/90 rounded-3xl border border-slate-800 shadow-2xl flex flex-col h-[560px] overflow-hidden">
        
        {/* Messages Container */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'ai' && (
                <div className="w-9 h-9 rounded-xl bg-teal-500/20 border border-teal-500/30 text-teal-400 flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5" />
                </div>
              )}

              <div className={`max-w-[82%] space-y-2 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
                
                {msg.image && (
                  <img src={msg.image} className="max-h-40 rounded-xl border border-slate-700 ml-auto" />
                )}

                <div
                  className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-teal-500 to-cyan-600 text-slate-950 font-semibold rounded-tr-none shadow-md'
                      : 'bg-slate-950 text-slate-100 border border-slate-800 rounded-tl-none shadow-md'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  <span className="text-[10px] text-slate-400 block mt-1 font-mono">{msg.timestamp}</span>
                </div>

                {/* Suggestions chips */}
                {msg.suggestions && msg.suggestions.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {msg.suggestions.map((sugg, i) => (
                      <button
                        key={i}
                        onClick={() => handleSuggestionClick(sugg)}
                        className="text-[11px] bg-slate-950 hover:bg-slate-800 text-teal-300 font-medium px-3 py-1 rounded-xl border border-teal-500/30 transition-all hover:scale-105"
                      >
                        {sugg} →
                      </button>
                    ))}
                  </div>
                )}

              </div>

              {msg.sender === 'user' && (
                <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 flex items-center justify-center shrink-0">
                  <User className="w-5 h-5" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-xs text-teal-400 bg-slate-950 p-3 rounded-2xl w-fit border border-slate-800">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>MEDI AI is thinking...</span>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Selected Image Preview Bar */}
        {selectedImage && (
          <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <span className="text-teal-400 font-medium">Image Attached for Clinical Analysis</span>
            <button onClick={() => setSelectedImage(null)} className="p-1 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
          
          <label className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer border border-slate-800">
            <ImageIcon className="w-4 h-4" />
            <input type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
          </label>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask medical questions, disease symptoms, or hospital queries..."
            className="flex-1 bg-slate-900 border border-slate-800 text-white px-4 py-2.5 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-teal-500"
          />

          <button
            onClick={() => handleSend()}
            disabled={loading}
            className="p-3 rounded-xl bg-gradient-to-r from-teal-400 to-cyan-500 text-slate-950 font-bold shadow-lg shadow-teal-500/20 hover:scale-105 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>

        </div>

      </div>

    </div>
  );
};
