import React, { useState } from 'react';
import { ShieldAlert, Building2, FileSearch, Users, Activity, CheckCircle2, AlertTriangle, DollarSign, ArrowUpRight, Ban } from 'lucide-react';
import { MOCK_HOSPITALS } from '../data/mockData';

export const AdminDashboard: React.FC = () => {
  const [hospitals, setHospitals] = useState(MOCK_HOSPITALS);
  const [fraudLogs, setFraudLogs] = useState([
    { id: 'f1', hospital: 'Apollo Super Specialty', billed: 142500, fair: 88000, savings: 54500, status: 'DISPUTE_OPEN' },
    { id: 'f2', hospital: 'City Cardiac Center', billed: 278750, fair: 190000, savings: 88750, status: 'RECOVERED' },
  ]);

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center space-x-2 bg-rose-500/10 text-rose-400 px-3 py-1 rounded-full text-xs font-bold border border-rose-500/30 mb-2">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>MEDI AI Platform Command Center</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            System Admin & Hospital ICU Network
          </h2>
          <p className="text-xs text-slate-400">Monitoring 280+ Hospitals, 108 Ambulance GPS Grid, and Bill Fraud Audits</p>
        </div>

        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-right space-y-1">
          <span className="text-[10px] text-emerald-400 font-bold uppercase block">TOTAL PATIENT SAVINGS GENERATED</span>
          <span className="text-2xl font-black text-emerald-400 font-mono">₹14,28,40,000</span>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold block">ACTIVE EMERGENCY SOS ALERTS</span>
          <div className="text-3xl font-black text-rose-500 font-mono">3 Live</div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold block">TOTAL ICU BEDS NETWORK</span>
          <div className="text-3xl font-black text-teal-400 font-mono">412 Available</div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold block">FRAUD AUDITS FILED</span>
          <div className="text-3xl font-black text-amber-400 font-mono">1,840 Cases</div>
        </div>

        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800/90 space-y-1">
          <span className="text-[10px] text-emerald-400 font-bold block">VERIFIED DOCTORS ON-CALL</span>
          <div className="text-3xl font-black text-emerald-400 font-mono">1,240</div>
        </div>
      </div>

      {/* Hospital ICU Bed Capacity Live Manager */}
      <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Building2 className="w-4 h-4 text-teal-400" />
          Live Hospital ICU Bed Capacity Manager
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3 rounded-l-xl">Hospital Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Available ICU Beds</th>
                <th className="p-3">Success Rate</th>
                <th className="p-3 rounded-r-xl text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {hospitals.map((hosp) => (
                <tr key={hosp.id} className="hover:bg-slate-950/60">
                  <td className="p-3 font-bold text-white">{hosp.name}</td>
                  <td className="p-3 text-slate-400">{hosp.grade}</td>
                  <td className="p-3 font-mono font-bold text-emerald-400">{hosp.icuBedsAvailable} / {hosp.totalIcuBeds}</td>
                  <td className="p-3 font-mono font-bold text-cyan-400">{hosp.successRatePercent}%</td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => {
                        setHospitals((prev) =>
                          prev.map((h) =>
                            h.id === hosp.id ? { ...h, icuBedsAvailable: Math.max(0, h.icuBedsAvailable - 1) } : h
                          )
                        );
                      }}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded"
                    >
                      Reserve ICU Bed
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Fraud Dispute Logs */}
      <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <FileSearch className="w-4 h-4 text-rose-500" />
          Active Hospital Bill Fraud Dispute Claims
        </h3>

        <div className="space-y-3">
          {fraudLogs.map((log) => (
            <div key={log.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div>
                <h4 className="font-bold text-white">{log.hospital}</h4>
                <p className="text-slate-400">Billed: ₹{log.billed.toLocaleString()} • Fair Value: ₹{log.fair.toLocaleString()}</p>
              </div>

              <div className="flex items-center space-x-3">
                <span className="font-mono font-bold text-emerald-400">Savings: ₹{log.savings.toLocaleString()}</span>
                <span className="px-2.5 py-1 bg-rose-500/20 text-rose-400 font-bold rounded text-[10px]">
                  {log.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
