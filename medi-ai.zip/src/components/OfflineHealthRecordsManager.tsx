import React, { useState, useEffect } from 'react';
import {
  Database,
  FileText,
  UserCheck,
  PhoneCall,
  Plus,
  Trash2,
  Edit2,
  Upload,
  CheckCircle2,
  AlertCircle,
  Search,
  Filter,
  ShieldCheck,
  FileImage,
  Download,
  Eye,
  Heart,
  Droplets,
  HardDrive,
  RefreshCw,
  Sparkles,
  Phone,
  Calendar,
  X
} from 'lucide-react';
import { UserHealthProfile, EmergencyContact, MedicalRecord } from '../types';
import {
  getHealthProfileFromIDB,
  saveHealthProfileToIDB,
  getEmergencyContactsFromIDB,
  saveEmergencyContactToIDB,
  deleteEmergencyContactFromIDB,
  getMedicalRecordsFromIDB,
  saveMedicalRecordToIDB,
  deleteMedicalRecordFromIDB
} from '../utils/offlineStorage';

interface OfflineHealthRecordsManagerProps {
  userProfile: UserHealthProfile;
  onProfileUpdated: (updatedProfile: UserHealthProfile) => void;
}

export const OfflineHealthRecordsManager: React.FC<OfflineHealthRecordsManagerProps> = ({
  userProfile,
  onProfileUpdated,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'contacts' | 'records'>('profile');

  // IndexedDB State
  const [healthProfile, setHealthProfile] = useState<UserHealthProfile>(userProfile);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Modals state
  const [showProfileEditModal, setShowProfileEditModal] = useState<boolean>(false);
  const [showContactModal, setShowContactModal] = useState<boolean>(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);

  const [showRecordModal, setShowRecordModal] = useState<boolean>(false);
  const [viewingRecord, setViewingRecord] = useState<MedicalRecord | null>(null);

  // Search & Filters for Medical Records
  const [recordSearch, setRecordSearch] = useState<string>('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('ALL');

  // New Contact Form State
  const [contactName, setContactName] = useState('');
  const [contactRelation, setContactRelation] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactPrimary, setContactPrimary] = useState(false);

  // New Medical Record Form State
  const [recTitle, setRecTitle] = useState('');
  const [recCategory, setRecCategory] = useState<MedicalRecord['category']>('Prescription');
  const [recDoctor, setRecDoctor] = useState('');
  const [recHospital, setRecHospital] = useState('');
  const [recDate, setRecDate] = useState(new Date().toISOString().split('T')[0]);
  const [recNotes, setRecNotes] = useState('');
  const [recFileDataUrl, setRecFileDataUrl] = useState<string | undefined>(undefined);
  const [recFileName, setRecFileName] = useState<string | undefined>(undefined);
  const [recTags, setRecTags] = useState('');

  // Load from IndexedDB on component mount
  useEffect(() => {
    loadAllIDBData();
  }, []);

  const loadAllIDBData = async () => {
    setIsLoading(true);
    try {
      const p = await getHealthProfileFromIDB();
      if (p) {
        setHealthProfile(p);
        onProfileUpdated(p);
      }

      const c = await getEmergencyContactsFromIDB();
      setContacts(c);

      const r = await getMedicalRecordsFromIDB();
      setRecords(r);
    } catch (err) {
      console.error('Error loading IndexedDB data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const triggerToast = (msg: string) => {
    setSaveSuccessMsg(msg);
    setTimeout(() => setSaveSuccessMsg(null), 3500);
  };

  // ==================== HEALTH PROFILE EDIT ====================
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveHealthProfileToIDB(healthProfile);
    onProfileUpdated(healthProfile);
    setShowProfileEditModal(false);
    triggerToast('Health Profile saved successfully to IndexedDB!');
  };

  // ==================== EMERGENCY CONTACTS ====================
  const handleOpenAddContact = () => {
    setEditingContact(null);
    setContactName('');
    setContactRelation('');
    setContactPhone('');
    setContactPrimary(false);
    setShowContactModal(true);
  };

  const handleOpenEditContact = (c: EmergencyContact) => {
    setEditingContact(c);
    setContactName(c.name);
    setContactRelation(c.relation);
    setContactPhone(c.phone);
    setContactPrimary(!!c.isPrimary);
    setShowContactModal(true);
  };

  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    const newContact: EmergencyContact = {
      id: editingContact ? editingContact.id : `ec-${Date.now()}`,
      name: contactName,
      relation: contactRelation,
      phone: contactPhone,
      isPrimary: contactPrimary,
    };

    await saveEmergencyContactToIDB(newContact);
    const updated = await getEmergencyContactsFromIDB();
    setContacts(updated);

    // Also update health profile emergency contacts summary
    const updatedProfile: UserHealthProfile = {
      ...healthProfile,
      emergencyContacts: updated,
    };
    await saveHealthProfileToIDB(updatedProfile);
    onProfileUpdated(updatedProfile);

    setShowContactModal(false);
    triggerToast(editingContact ? 'Emergency contact updated in IndexedDB.' : 'New emergency contact saved to IndexedDB.');
  };

  const handleDeleteContact = async (id: string) => {
    if (confirm('Are you sure you want to delete this emergency contact from IndexedDB storage?')) {
      await deleteEmergencyContactFromIDB(id);
      const updated = await getEmergencyContactsFromIDB();
      setContacts(updated);
      triggerToast('Emergency contact removed from IndexedDB.');
    }
  };

  // ==================== MEDICAL RECORDS ====================
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setRecFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        setRecFileDataUrl(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveMedicalRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recTitle) return;

    const newRecord: MedicalRecord = {
      id: `rec-${Date.now()}`,
      title: recTitle,
      category: recCategory,
      doctorName: recDoctor || undefined,
      hospitalName: recHospital || undefined,
      date: recDate,
      notes: recNotes || undefined,
      fileDataUrl: recFileDataUrl,
      fileName: recFileName,
      tags: recTags ? recTags.split(',').map((t) => t.trim()) : [],
      createdAt: new Date().toISOString(),
    };

    await saveMedicalRecordToIDB(newRecord);
    const updatedRecords = await getMedicalRecordsFromIDB();
    setRecords(updatedRecords);

    // Reset Form
    setRecTitle('');
    setRecDoctor('');
    setRecHospital('');
    setRecNotes('');
    setRecFileDataUrl(undefined);
    setRecFileName(undefined);
    setRecTags('');
    setShowRecordModal(false);

    triggerToast('Medical record stored securely in IndexedDB!');
  };

  const handleDeleteRecord = async (id: string) => {
    if (confirm('Delete this medical record from IndexedDB vault?')) {
      await deleteMedicalRecordFromIDB(id);
      const updatedRecords = await getMedicalRecordsFromIDB();
      setRecords(updatedRecords);
      if (viewingRecord?.id === id) setViewingRecord(null);
      triggerToast('Medical record deleted from IndexedDB.');
    }
  };

  // Filter records
  const filteredRecords = records.filter((r) => {
    const matchesCategory = selectedCategoryFilter === 'ALL' || r.category === selectedCategoryFilter;
    const q = recordSearch.toLowerCase();
    const matchesSearch =
      r.title.toLowerCase().includes(q) ||
      (r.doctorName && r.doctorName.toLowerCase().includes(q)) ||
      (r.hospitalName && r.hospitalName.toLowerCase().includes(q)) ||
      (r.tags && r.tags.some((t) => t.toLowerCase().includes(q)));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6 bg-slate-900/80 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl relative overflow-hidden text-slate-100">
      
      {/* Toast Notification */}
      {saveSuccessMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-500 text-slate-950 font-black px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 text-xs animate-in fade-in zoom-in duration-200">
          <CheckCircle2 className="w-5 h-5" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* Top Header Badge */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-2 bg-teal-500/20 text-teal-300 rounded-xl border border-teal-500/30">
              <HardDrive className="w-5 h-5 animate-pulse" />
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              IndexedDB Offline Records Vault
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Persistent local storage for health profile, emergency contacts & prescriptions — completely functional without network connection.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 px-3 py-1.5 rounded-2xl border border-teal-500/30 text-xs font-mono text-teal-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>IndexedDB Status: <strong>ONLINE & OFFLINE ACTIVE</strong></span>
        </div>
      </div>

      {/* Subtabs Selector */}
      <div className="flex border-b border-slate-800 gap-2 sm:gap-6 text-xs font-bold">
        <button
          onClick={() => setActiveSubTab('profile')}
          className={`pb-3 transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'profile'
              ? 'border-teal-400 text-teal-300 font-extrabold'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          Health Profile ({healthProfile.name.split(' ')[0]})
        </button>

        <button
          onClick={() => setActiveSubTab('contacts')}
          className={`pb-3 transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'contacts'
              ? 'border-teal-400 text-teal-300 font-extrabold'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <PhoneCall className="w-4 h-4" />
          Emergency Contacts ({contacts.length})
        </button>

        <button
          onClick={() => setActiveSubTab('records')}
          className={`pb-3 transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'records'
              ? 'border-teal-400 text-teal-300 font-extrabold'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4" />
          Medical Records ({records.length})
        </button>
      </div>

      {/* SUBTAB 1: HEALTH PROFILE */}
      {activeSubTab === 'profile' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              IndexedDB Persisted User Health Profile
            </h3>
            <button
              onClick={() => setShowProfileEditModal(true)}
              className="px-3.5 py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow"
            >
              <Edit2 className="w-3.5 h-3.5" />
              Edit Health Profile
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Personal Vitals Card */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <span className="text-xs text-teal-400 font-mono font-bold uppercase block">
                Basic Demographics
              </span>
              <div className="text-xs space-y-1.5 text-slate-300">
                <p><strong className="text-white">Full Name:</strong> {healthProfile.name}</p>
                <p><strong className="text-white">Age / Gender:</strong> {healthProfile.age} yrs • {healthProfile.gender}</p>
                <p><strong className="text-white">Blood Group:</strong> <span className="text-rose-400 font-bold">{healthProfile.bloodGroup}</span></p>
                <p><strong className="text-white">Weight & Height:</strong> {healthProfile.weightKg} kg • {healthProfile.heightCm} cm</p>
                <p><strong className="text-white">Calculated BMI:</strong> {healthProfile.bmi}</p>
              </div>
            </div>

            {/* Medical History & Allergies */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <span className="text-xs text-rose-400 font-mono font-bold uppercase block">
                Conditions & Allergies
              </span>
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Chronic Conditions:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {healthProfile.chronicConditions.map((cond, i) => (
                      <span key={i} className="bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded text-[10px] font-medium">
                        {cond}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">Drug & Food Allergies:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {healthProfile.allergies.map((allg, i) => (
                      <span key={i} className="bg-rose-500/10 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded text-[10px] font-medium">
                        ⚠️ {allg}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Government & Insurance Identifiers */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <span className="text-xs text-cyan-400 font-mono font-bold uppercase block">
                Health ID & Insurance
              </span>
              <div className="text-xs space-y-1.5 text-slate-300">
                <p><strong className="text-white">ABHA Health ID:</strong> <span className="font-mono text-teal-300">{healthProfile.ayushmanId}</span></p>
                <p><strong className="text-white">Insurance Provider:</strong> {healthProfile.insuranceProvider}</p>
                <p><strong className="text-white">Policy Number:</strong> <span className="font-mono">{healthProfile.insurancePolicyNumber}</span></p>
                <p><strong className="text-white">Health Score:</strong> <span className="text-emerald-400 font-bold">{healthProfile.healthScore}/100</span></p>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* SUBTAB 2: EMERGENCY CONTACTS */}
      {activeSubTab === 'contacts' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                IndexedDB Saved Emergency Family Contacts
              </h3>
              <p className="text-xs text-slate-400">These contacts are accessible instantly offline during SOS alerts.</p>
            </div>
            <button
              onClick={handleOpenAddContact}
              className="px-3.5 py-1.5 bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Emergency Contact
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {contacts.map((c) => (
              <div key={c.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between space-x-3 relative">
                <div>
                  <div className="flex items-center space-x-2">
                    <h4 className="text-sm font-bold text-white">{c.name}</h4>
                    {c.isPrimary && (
                      <span className="bg-rose-500/20 text-rose-300 text-[10px] font-mono px-2 py-0.2 rounded border border-rose-500/30">
                        PRIMARY SOS
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-teal-400 font-medium">{c.relation}</p>
                  <p className="text-xs text-slate-300 font-mono mt-1">{c.phone}</p>
                </div>

                <div className="flex items-center space-x-1">
                  <a href={`tel:${c.phone}`} className="p-2 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 rounded-xl" title="Direct Phone Call">
                    <Phone className="w-4 h-4" />
                  </a>
                  <button onClick={() => handleOpenEditContact(c)} className="p-2 text-slate-400 hover:text-white rounded-xl" title="Edit Contact">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDeleteContact(c.id)} className="p-2 text-slate-400 hover:text-rose-400 rounded-xl" title="Delete Contact">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 3: MEDICAL RECORDS VAULT */}
      {activeSubTab === 'records' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Offline Medical Records & Prescription Vault
              </h3>
              <p className="text-xs text-slate-400">Stores lab reports, doctor prescriptions and X-rays locally in IndexedDB.</p>
            </div>

            <button
              onClick={() => setShowRecordModal(true)}
              className="px-4 py-2 bg-gradient-to-r from-teal-500 via-cyan-500 to-emerald-500 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 shadow"
            >
              <Upload className="w-4 h-4" />
              Upload New Medical Record
            </button>
          </div>

          {/* Search & Category Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                placeholder="Search medical records by title, doctor, hospital or tag..."
                value={recordSearch}
                onChange={(e) => setRecordSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            <select
              value={selectedCategoryFilter}
              onChange={(e) => setSelectedCategoryFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-teal-500"
            >
              <option value="ALL">All Categories</option>
              <option value="Prescription">Prescription</option>
              <option value="Lab Report">Lab Report</option>
              <option value="Discharge Summary">Discharge Summary</option>
              <option value="Vaccination">Vaccination</option>
              <option value="Insurance Claim">Insurance Claim</option>
              <option value="Imaging / X-Ray">Imaging / X-Ray</option>
            </select>
          </div>

          {/* Records Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredRecords.length > 0 ? (
              filteredRecords.map((r) => (
                <div key={r.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col justify-between space-y-3 hover:border-teal-500/40 transition-all">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] bg-teal-500/20 text-teal-300 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/30">
                        {r.category}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-500" />
                        {r.date}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-white mt-2 leading-snug">{r.title}</h4>
                    {r.doctorName && <p className="text-xs text-slate-400 mt-1">👨‍⚕️ {r.doctorName}</p>}
                    {r.hospitalName && <p className="text-xs text-slate-400">🏥 {r.hospitalName}</p>}

                    {r.notes && (
                      <p className="text-xs text-slate-300 mt-2 bg-slate-900/60 p-2 rounded-lg line-clamp-2 italic">
                        "{r.notes}"
                      </p>
                    )}

                    {r.tags && r.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {r.tags.map((t, i) => (
                          <span key={i} className="text-[10px] bg-slate-900 text-slate-400 px-1.5 py-0.2 rounded border border-slate-800">
                            #{t}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-900 flex items-center justify-between text-xs">
                    {r.fileDataUrl ? (
                      <button
                        onClick={() => setViewingRecord(r)}
                        className="text-teal-400 hover:underline font-bold flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        View Document
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-500 italic">No File Attached</span>
                    )}

                    <button
                      onClick={() => handleDeleteRecord(r.id)}
                      className="text-slate-500 hover:text-rose-400"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full py-12 text-center text-slate-400 space-y-2">
                <FileText className="w-8 h-8 mx-auto text-slate-600" />
                <p className="text-sm font-bold">No Medical Records found in IndexedDB</p>
                <p className="text-xs text-slate-500">Upload a new record above to store it locally on your device.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 1: EDIT HEALTH PROFILE */}
      {showProfileEditModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-teal-400" />
                Edit IndexedDB Health Profile
              </h3>
              <button onClick={() => setShowProfileEditModal(false)} className="text-slate-400">✕</button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Full Name</label>
                  <input
                    type="text"
                    value={healthProfile.name}
                    onChange={(e) => setHealthProfile({ ...healthProfile, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Age</label>
                  <input
                    type="number"
                    value={healthProfile.age}
                    onChange={(e) => setHealthProfile({ ...healthProfile, age: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Gender</label>
                  <select
                    value={healthProfile.gender}
                    onChange={(e) => setHealthProfile({ ...healthProfile, gender: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Blood Group</label>
                  <select
                    value={healthProfile.bloodGroup}
                    onChange={(e) => setHealthProfile({ ...healthProfile, bloodGroup: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((bg) => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={healthProfile.weightKg}
                    onChange={(e) => {
                      const w = parseFloat(e.target.value) || 0;
                      const hMeter = healthProfile.heightCm / 100;
                      const bmi = hMeter > 0 ? parseFloat((w / (hMeter * hMeter)).toFixed(1)) : healthProfile.bmi;
                      setHealthProfile({ ...healthProfile, weightKg: w, bmi });
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Height (cm)</label>
                  <input
                    type="number"
                    value={healthProfile.heightCm}
                    onChange={(e) => {
                      const h = parseFloat(e.target.value) || 0;
                      const hMeter = h / 100;
                      const bmi = hMeter > 0 ? parseFloat((healthProfile.weightKg / (hMeter * hMeter)).toFixed(1)) : healthProfile.bmi;
                      setHealthProfile({ ...healthProfile, heightCm: h, bmi });
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Chronic Conditions (comma separated)</label>
                <input
                  type="text"
                  value={healthProfile.chronicConditions.join(', ')}
                  onChange={(e) => setHealthProfile({ ...healthProfile, chronicConditions: e.target.value.split(',').map((s) => s.trim()) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Allergies (comma separated)</label>
                <input
                  type="text"
                  value={healthProfile.allergies.join(', ')}
                  onChange={(e) => setHealthProfile({ ...healthProfile, allergies: e.target.value.split(',').map((s) => s.trim()) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Insurance Provider</label>
                <input
                  type="text"
                  value={healthProfile.insuranceProvider || ''}
                  onChange={(e) => setHealthProfile({ ...healthProfile, insuranceProvider: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Ayushman / ABHA Health ID</label>
                <input
                  type="text"
                  value={healthProfile.ayushmanId || ''}
                  onChange={(e) => setHealthProfile({ ...healthProfile, ayushmanId: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowProfileEditModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-500 text-slate-950 font-black rounded-xl"
                >
                  Save Profile to IndexedDB
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: ADD / EDIT EMERGENCY CONTACT */}
      {showContactModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <PhoneCall className="w-5 h-5 text-teal-400" />
                {editingContact ? 'Edit Emergency Contact' : 'Add New Emergency Contact'}
              </h3>
              <button onClick={() => setShowContactModal(false)} className="text-slate-400">✕</button>
            </div>

            <form onSubmit={handleSaveContact} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-bold block mb-1">Contact Name</label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  placeholder="e.g. Priya Sharma"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Relationship</label>
                <input
                  type="text"
                  value={contactRelation}
                  onChange={(e) => setContactRelation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  placeholder="e.g. Spouse, Parent, Brother"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Phone Number</label>
                <input
                  type="text"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  placeholder="+91 98765 43210"
                  required
                />
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="primaryContact"
                  checked={contactPrimary}
                  onChange={(e) => setContactPrimary(e.target.checked)}
                  className="rounded border-slate-800 text-teal-500 focus:ring-teal-500"
                />
                <label htmlFor="primaryContact" className="text-xs text-slate-300 font-bold">
                  Set as Primary SOS Emergency Contact
                </label>
              </div>

              <div className="pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowContactModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-500 text-slate-950 font-black rounded-xl"
                >
                  Save to IndexedDB
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: UPLOAD MEDICAL RECORD */}
      {showRecordModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-teal-400" />
                Upload Record to IndexedDB Vault
              </h3>
              <button onClick={() => setShowRecordModal(false)} className="text-slate-400">✕</button>
            </div>

            <form onSubmit={handleSaveMedicalRecord} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-bold block mb-1">Document Title *</label>
                <input
                  type="text"
                  value={recTitle}
                  onChange={(e) => setRecTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  placeholder="e.g. Cardiology OPD Prescription"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Category</label>
                  <select
                    value={recCategory}
                    onChange={(e) => setRecCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Prescription">Prescription</option>
                    <option value="Lab Report">Lab Report</option>
                    <option value="Discharge Summary">Discharge Summary</option>
                    <option value="Vaccination">Vaccination</option>
                    <option value="Insurance Claim">Insurance Claim</option>
                    <option value="Imaging / X-Ray">Imaging / X-Ray</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 font-bold block mb-1">Record Date</label>
                  <input
                    type="date"
                    value={recDate}
                    onChange={(e) => setRecDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold block mb-1">Doctor Name</label>
                  <input
                    type="text"
                    value={recDoctor}
                    onChange={(e) => setRecDoctor(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                    placeholder="e.g. Dr. Arvind Swaminathan"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold block mb-1">Hospital / Clinic</label>
                  <input
                    type="text"
                    value={recHospital}
                    onChange={(e) => setRecHospital(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                    placeholder="e.g. Apollo Hospital"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Clinical Notes & Summary</label>
                <textarea
                  value={recNotes}
                  onChange={(e) => setRecNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white h-20"
                  placeholder="Enter medical notes or dosage instructions..."
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Attach File / Image (Stored offline in IndexedDB)</label>
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={handleFileUpload}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 text-xs"
                />
                {recFileName && (
                  <p className="text-[11px] text-teal-400 font-mono mt-1">✓ File ready: {recFileName}</p>
                )}
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  value={recTags}
                  onChange={(e) => setRecTags(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  placeholder="e.g. Heart, Cholesterol, Blood"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowRecordModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 font-black rounded-xl"
                >
                  Save Record to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: VIEW RECORD DOCUMENT ATTACHMENT */}
      {viewingRecord && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">{viewingRecord.title}</h3>
                <p className="text-xs text-teal-400 font-mono">{viewingRecord.category} • {viewingRecord.date}</p>
              </div>
              <button onClick={() => setViewingRecord(null)} className="text-slate-400">✕</button>
            </div>

            {viewingRecord.fileDataUrl ? (
              <div className="bg-slate-950 p-2 rounded-2xl border border-slate-800 text-center">
                {viewingRecord.fileDataUrl.startsWith('data:image') ? (
                  <img src={viewingRecord.fileDataUrl} alt={viewingRecord.title} className="max-h-80 mx-auto rounded-xl object-contain" />
                ) : (
                  <div className="p-8 text-xs text-slate-300">
                    <FileText className="w-12 h-12 mx-auto text-teal-400 mb-2" />
                    <span>PDF Document Attachment: {viewingRecord.fileName || 'Attached Document'}</span>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-slate-400">No image attachment provided.</p>
            )}

            {viewingRecord.notes && (
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-300">
                <strong className="text-white block mb-1">Clinical Notes:</strong>
                {viewingRecord.notes}
              </div>
            )}

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={() => handleDeleteRecord(viewingRecord.id)}
                className="text-xs text-rose-400 font-bold hover:underline"
              >
                Delete Record
              </button>
              <button
                onClick={() => setViewingRecord(null)}
                className="px-4 py-2 bg-slate-800 text-slate-200 font-bold text-xs rounded-xl"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
