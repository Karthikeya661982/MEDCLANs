import React, { useState, useEffect } from 'react';
import { ShieldAlert, Phone, Navigation, AlertTriangle, CheckCircle2, User, Volume2, VolumeX, Ambulance, Clock, MapPin, Share2 } from 'lucide-react';
import { MOCK_HOSPITALS, MOCK_DOCTORS } from '../data/mockData';
import { EmergencyContact } from '../types';
import { getEmergencyContactsFromIDB } from '../utils/offlineStorage';

interface EmergencySOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDoctor?: (doc: any) => void;
}

export const EmergencySOSModal: React.FC<EmergencySOSModalProps> = ({
  isOpen,
  onClose,
  onSelectDoctor,
}) => {
  const [sosActivated, setSosActivated] = useState(false);
  const [eta, setEta] = useState(8);
  const [sirenSound, setSirenSound] = useState(true);
  const [sharedLocation, setSharedLocation] = useState(false);
  const [userCoords, setUserCoords] = useState({ lat: 17.4325, lng: 78.4071, address: "Road No. 36, Jubilee Hills, Hyderabad" });
  const [idbContacts, setIdbContacts] = useState<EmergencyContact[]>([]);

  useEffect(() => {
    if (isOpen) {
      getEmergencyContactsFromIDB().then((contacts) => {
        if (contacts && contacts.length > 0) {
          setIdbContacts(contacts);
        }
      });
    }
  }, [isOpen]);

  useEffect(() => {
    if (sosActivated && eta > 1) {
      const timer = setInterval(() => setEta((prev) => prev - 1), 2000);
      return () => clearInterval(timer);
    }
  }, [sosActivated, eta]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-2xl p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border-2 border-rose-500/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 animate-in zoom-in-95">
        
        {/* Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-2xl bg-rose-600/20 text-rose-500 border border-rose-500/30 animate-pulse">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white uppercase tracking-wider flex items-center gap-2">
                EMERGENCY SOS RESPONSE
                <span className="text-xs bg-rose-600 text-white font-bold px-2 py-0.5 rounded-full animate-ping">
                  LIVE
                </span>
              </h2>
              <p className="text-xs text-rose-300 font-medium">
                1-Click Emergency GPS Dispatcher & Hospital Locator
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            ✕
          </button>
        </div>

        {/* SOS Action Toggle / State */}
        {!sosActivated ? (
          <div className="text-center py-6 space-y-6">
            <div className="relative inline-block">
              <span className="absolute -inset-4 rounded-full bg-rose-600/30 animate-ping" />
              <button
                onClick={() => setSosActivated(true)}
                className="relative w-36 h-36 rounded-full bg-gradient-to-br from-rose-500 via-red-600 to-rose-700 text-white font-black text-xl shadow-2xl shadow-rose-600/50 hover:scale-105 active:scale-95 transition-all border-4 border-white flex flex-col items-center justify-center space-y-1 mx-auto"
              >
                <ShieldAlert className="w-10 h-10 animate-bounce" />
                <span>TAP SOS</span>
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-left space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
                <span className="flex items-center gap-1 text-teal-400">
                  <MapPin className="w-3.5 h-3.5" />
                  ACQUIRED GPS LOCATION
                </span>
                <span className="text-emerald-400">Accuracy: 3 meters</span>
              </div>
              <p className="text-sm font-bold text-white font-mono">{userCoords.address}</p>
            </div>

            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Activating SOS instantly transmits your real-time GPS coordinates to 108 Emergency Ambulance Dispatch, notifies emergency family contacts, and reserves nearest hospital ICU bed.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* Active SOS Alarm Banner */}
            <div className="p-4 rounded-2xl bg-rose-600/20 border border-rose-500/50 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Ambulance className="w-8 h-8 text-rose-400 animate-bounce" />
                <div>
                  <h4 className="text-sm font-bold text-rose-200">AMBULANCE DISPATCHED</h4>
                  <p className="text-xs text-rose-300 font-mono">Unit #HYD-108-APOLLO • Driver: Ramesh K. (+91 98490 10800)</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black text-white font-mono">{eta} MINS</span>
                <p className="text-[10px] text-rose-400 font-bold uppercase">ESTIMATED ARRIVAL</p>
              </div>
            </div>

            {/* Emergency Contacts Notification Alert */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center space-x-3">
                <Share2 className="w-5 h-5 text-teal-400" />
                <div>
                  <p className="text-xs font-bold text-white">Live Location Shared with IndexedDB Emergency Contacts</p>
                  <p className="text-[11px] text-slate-400">
                    {idbContacts.length > 0
                      ? idbContacts.map((c) => `${c.name} (${c.relation}: ${c.phone})`).join(', ')
                      : 'Priya Sharma (Spouse), Rajesh Sharma (Father)'}
                  </p>
                </div>
              </div>
              <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1 self-start sm:self-auto">
                <CheckCircle2 className="w-3.5 h-3.5" />
                SMS DISPATCHED
              </span>
            </div>

            {/* Nearest ER Hospitals with Live ICU Beds */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                <span>NEAREST EMERGENCY ROOMS (RESERVED)</span>
                <span className="text-teal-400">Live ICU Bed Feeds</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {MOCK_HOSPITALS.slice(0, 2).map((hosp) => (
                  <div key={hosp.id} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-bold text-white">{hosp.name}</h5>
                      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">
                        {hosp.icuBedsAvailable} ICU Beds
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">{hosp.address}</p>
                    <div className="flex items-center justify-between pt-1 text-[11px]">
                      <span className="text-teal-400 font-medium">{hosp.distanceKm} km away</span>
                      <a
                        href={`tel:${hosp.phone}`}
                        className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-[10px] flex items-center gap-1"
                      >
                        <Phone className="w-3 h-3" /> Call ER
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Emergency Direct Call & Offline SMS Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
              <a
                href="tel:108"
                className="flex-1 py-3 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs sm:text-sm rounded-xl text-center shadow-lg flex items-center justify-center gap-2 transition-all transform active:scale-98"
              >
                <Phone className="w-4 h-4" />
                DIRECT CALL 108 AMBULANCE
              </a>

              <a
                href={`sms:+919849010800?body=${encodeURIComponent(`EMERGENCY SOS ALERT! I need immediate medical ambulance help. Location: ${userCoords.address} (GPS: ${userCoords.lat}, ${userCoords.lng}). Sent via MEDCLAN Offline SOS.`)}`}
                className="flex-1 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-black text-xs sm:text-sm rounded-xl text-center shadow-lg flex items-center justify-center gap-2 transition-all transform active:scale-98"
              >
                <Share2 className="w-4 h-4" />
                SEND OFFLINE EMERGENCY SMS
              </a>

              <button
                onClick={() => setSosActivated(false)}
                className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl"
              >
                Reset SOS
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
