import React, { useState } from 'react';
import { Calculator, Sparkles, TrendingDown, Building2, ShieldCheck, DollarSign, PieChart, HelpCircle, ArrowRight } from 'lucide-react';

export const CostEstimator: React.FC = () => {
  const [disease, setDisease] = useState('Coronary Angioplasty');
  const [hospitalType, setHospitalType] = useState('Super Specialty');
  const [age, setAge] = useState(54);
  const [insurance, setInsurance] = useState('Cashless Health Insurance (HDFC ERGO / Star)');
  const [city, setCity] = useState('Metro (Hyderabad / Mumbai / Delhi)');
  
  const [loading, setLoading] = useState(false);
  const [estimation, setEstimation] = useState<any | null>(null);

  const commonProcedures = [
    'Coronary Angioplasty',
    'Total Knee Replacement',
    'Laparoscopic Gallbladder Surgery',
    'C-Section Delivery',
    'Cataract Eye Surgery',
    'Appendectomy',
    'Dengue Fever ICU Stay',
  ];

  const handleCalculate = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/ai/estimate-cost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ disease, hospitalType, age, insurance, city }),
      });
      const data = await response.json();
      setEstimation(data);
    } catch (error) {
      console.error("Cost Estimation Error", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-cyan-950/30 to-slate-950 p-6 sm:p-8 rounded-3xl border border-cyan-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 bg-cyan-500/10 text-cyan-400 px-3 py-1 rounded-full text-xs font-bold border border-cyan-500/30">
              <Calculator className="w-3.5 h-3.5" />
              <span>AI Hospital Expense Prediction Engine</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              AI Treatment Cost Estimator
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Get transparent itemized expense estimates for surgeries, ICU stays, medications, and doctor fees before stepping into a hospital.
            </p>
          </div>

          <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 text-center space-y-1">
            <span className="text-xs text-slate-400 font-bold uppercase block">FAIR PRICE GUARANTEE</span>
            <span className="text-sm font-bold text-teal-400">NPPA & ABDM Rate Standards</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Input Form */}
        <div className="lg:col-span-5 bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-5 shadow-xl">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            Enter Treatment & Patient Details
          </h3>

          <div className="space-y-4 text-xs">
            
            {/* Disease / Procedure Input */}
            <div>
              <label className="text-slate-400 font-bold block mb-1">DISEASE OR SURGICAL PROCEDURE</label>
              <input
                type="text"
                value={disease}
                onChange={(e) => setDisease(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-500"
                placeholder="e.g. Knee Replacement or Angioplasty"
              />
              <div className="flex flex-wrap gap-1.5 mt-2">
                {commonProcedures.map((proc) => (
                  <button
                    key={proc}
                    onClick={() => setDisease(proc)}
                    className="text-[10px] bg-slate-950 text-slate-400 hover:text-white px-2.5 py-1 rounded-lg border border-slate-800"
                  >
                    {proc}
                  </button>
                ))}
              </div>
            </div>

            {/* Hospital Grade Selector */}
            <div>
              <label className="text-slate-400 font-bold block mb-1">HOSPITAL CATEGORY</label>
              <select
                value={hospitalType}
                onChange={(e) => setHospitalType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-500"
              >
                <option>Super Specialty (NABH Accredited)</option>
                <option>Multi Specialty Corporate</option>
                <option>Government Medical College Hospital</option>
                <option>Local Nursing Home / Clinic</option>
              </select>
            </div>

            {/* Age & City */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 font-bold block mb-1">PATIENT AGE</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">CITY TIER</label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-500"
                >
                  <option>Metro (Hyderabad/Mumbai/Delhi)</option>
                  <option>Tier 2 (Vizag/Nagpur/Coimbatore)</option>
                  <option>Tier 3 / Rural District</option>
                </select>
              </div>
            </div>

            {/* Insurance */}
            <div>
              <label className="text-slate-400 font-bold block mb-1">INSURANCE STATUS</label>
              <select
                value={insurance}
                onChange={(e) => setInsurance(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-500"
              >
                <option>Cashless Health Insurance (HDFC ERGO / Star)</option>
                <option>Ayushman Bharat PM-JAY Card</option>
                <option>Aarogyasri / State Relief</option>
                <option>No Insurance (Out of Pocket)</option>
              </select>
            </div>

            <button
              onClick={handleCalculate}
              disabled={loading}
              className="w-full py-3.5 bg-gradient-to-r from-teal-400 via-cyan-500 to-emerald-500 text-slate-950 font-black text-sm rounded-xl shadow-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
            >
              {loading ? "Calculating Expenses..." : "Predict Itemized Cost Breakdown"}
              <ArrowRight className="w-4 h-4" />
            </button>

          </div>
        </div>

        {/* Estimation Output Card */}
        <div className="lg:col-span-7 bg-slate-900/90 p-6 sm:p-8 rounded-3xl border border-slate-800/90 space-y-6">
          {estimation ? (
            <div className="space-y-6">
              
              {/* Total Cost Callout */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-teal-500/20 via-cyan-500/10 to-slate-950 border border-teal-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-teal-400 uppercase tracking-wider block">PREDICTED TOTAL EXPENSE</span>
                  <h3 className="text-3xl font-black text-white font-mono mt-1">
                    ₹{estimation.totalEstimatedExpense?.toLocaleString()}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">Fair Market Range: <strong className="text-emerald-400">{estimation.fairMarketRange}</strong></p>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-[10px] bg-teal-500/10 text-teal-300 px-3 py-1 rounded-full border border-teal-500/30 font-bold inline-block">
                    {estimation.governmentCoverage}
                  </span>
                </div>
              </div>

              {/* Expense Itemized Breakdown Progress Bars */}
              <div className="space-y-4 bg-slate-950 p-5 rounded-2xl border border-slate-800">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">ITEMIZED EXPENSE BREAKDOWN (INR)</h4>
                
                {Object.entries(estimation.breakdown || {}).map(([key, value]) => {
                  const val = Number(value);
                  const total = estimation.totalEstimatedExpense || 1;
                  const percent = Math.round((val / total) * 100);

                  return (
                    <div key={key} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="capitalize font-semibold text-slate-300">{key.replace(/([A-Z])/g, ' $1')}</span>
                        <span className="font-mono text-white font-bold">₹{val.toLocaleString()} ({percent}%)</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-teal-400 to-cyan-500 rounded-full"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* AI Cost Savings Tips */}
              <div className="space-y-3 bg-slate-950/80 p-5 rounded-2xl border border-slate-800">
                <h4 className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 uppercase">
                  <TrendingDown className="w-4 h-4" />
                  AI COST SAVINGS SUGGESTIONS
                </h4>
                <ul className="space-y-2 text-xs text-slate-300">
                  {estimation.savingsSuggestions?.map((tip: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-teal-400 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>
          ) : (
            <div className="py-24 text-center space-y-3">
              <Calculator className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-400">Fill in treatment details on the left and click calculate to generate a instant price estimate.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
