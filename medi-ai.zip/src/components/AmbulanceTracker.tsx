import React, { useState, useEffect } from 'react';
import { Ambulance, MapPin, Phone, Clock, Navigation, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { InteractiveMap } from './InteractiveMap';

export const AmbulanceTracker: React.FC = () => {
  const [etaMinutes, setEtaMinutes] = useState(6);
  const [status, setStatus] = useState<'EN_ROUTE' | 'NEARBY' | 'ARRIVED'>('EN_ROUTE');

  useEffect(() => {
    if (etaMinutes > 1) {
      const timer = setInterval(() => setEtaMinutes((prev) => prev - 1), 3000);
      return () => clearInterval(timer);
    } else {
      setStatus('ARRIVED');
    }
  }, [etaMinutes]);

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-rose-950/40 to-slate-950 p-6 sm:p-8 rounded-3xl border border-rose-500/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center space-x-2 bg-rose-500/10 text-rose-400 px-3 py-1 rounded-full text-xs font-bold border border-rose-500/30">
            <Ambulance className="w-3.5 h-3.5 animate-bounce" />
            <span>Smart 108 Emergency GPS Ambulance Dispatch</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            Smart Ambulance Live Tracker
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Real-time GPS movement tracking, AI green-corridor signal clearance prediction, and live hospital ER pre-admission broadcast.
          </p>
        </div>

        <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 text-center">
          <span className="text-[10px] text-rose-400 font-bold uppercase block">ESTIMATED ARRIVAL TIME</span>
          <span className="text-3xl font-black text-white font-mono">{etaMinutes} MINS</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Live GPS Map Visualizer */}
        <div className="lg:col-span-7">
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>LIVE AMBULANCE VEHICLE POSITION</span>
              <span className="text-emerald-400 font-mono">GPS Signal Strength: 100%</span>
            </h3>
            <InteractiveMap activeItemType="ambulance" showRoute={true} />
          </div>
        </div>

        {/* Dispatch Controls & Driver Info */}
        <div className="lg:col-span-5 bg-slate-900/90 p-6 rounded-3xl border border-slate-800/90 space-y-6 shadow-xl">
          
          <div className="p-4 rounded-2xl bg-rose-600/20 border border-rose-500/50 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-rose-300 uppercase block">DISPATCH STATUS</span>
              <h4 className="text-lg font-black text-white">{status === 'ARRIVED' ? 'AMBULANCE AT LOCATION' : 'ADVANCED LIFE SUPPORT EN ROUTE'}</h4>
            </div>
            <Ambulance className="w-8 h-8 text-rose-400 animate-pulse" />
          </div>

          <div className="space-y-3 text-xs bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <div className="flex justify-between text-slate-400">
              <span>Vehicle Number:</span>
              <strong className="text-white font-mono">AP-09-108-APOLLO</strong>
            </div>

            <div className="flex justify-between text-slate-400">
              <span>Ambulance Driver:</span>
              <strong className="text-white font-semibold">Ramesh Kumar (+91 98490 10800)</strong>
            </div>

            <div className="flex justify-between text-slate-400">
              <span>Paramedic Team:</span>
              <strong className="text-teal-400">Dr. K. Srinivas (ICU Paramedic)</strong>
            </div>

            <div className="flex justify-between text-slate-400">
              <span>Assigned Hospital:</span>
              <strong className="text-white">Apollo Jubilee Hills ER</strong>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center space-x-2 text-xs font-bold text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              <span>AI Traffic Corridor Cleared</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Green wave traffic signal priority enabled along Jubilee Hills Road No. 36. Hospital Trauma Team prepped with ICU Ventilator Bed #4.
            </p>
          </div>

          <a
            href="tel:+919849010800"
            className="w-full py-3.5 bg-gradient-to-r from-rose-600 to-red-600 text-white font-black text-xs rounded-xl shadow-lg text-center flex items-center justify-center gap-2"
          >
            <Phone className="w-4 h-4" />
            CALL AMBULANCE DRIVER DIRECTLY
          </a>

        </div>

      </div>

    </div>
  );
};
