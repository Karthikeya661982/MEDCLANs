import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { NearbyDoctorFinder } from './components/NearbyDoctorFinder';
import { BillFraudDetector } from './components/BillFraudDetector';
import { CostEstimator } from './components/CostEstimator';
import { HospitalComparator } from './components/HospitalComparator';
import { GovernmentSchemes } from './components/GovernmentSchemes';
import { PrescriptionScanner } from './components/PrescriptionScanner';
import { AIChatbot } from './components/AIChatbot';
import { SymptomChecker } from './components/SymptomChecker';
import { AmbulanceTracker } from './components/AmbulanceTracker';
import { EmergencySOSModal } from './components/EmergencySOSModal';
import { UserDashboard } from './components/UserDashboard';
import { DoctorDashboard } from './components/DoctorDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { VideoConsultation } from './components/VideoConsultation';

import { MOCK_USER, MOCK_APPOINTMENTS } from './data/mockData';
import { Language, UserRole, Appointment, Doctor, UserHealthProfile } from './types';
import { seedInitialOfflineStorage, saveAppointmentToIDB } from './utils/offlineStorage';
import { ShieldAlert, HeartPulse, Building2, Calculator, Pill, FileSearch, Sparkles, Phone, MessageSquare, ArrowRight, CheckCircle2 } from 'lucide-react';

export function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [currentRole, setCurrentRole] = useState<UserRole>('patient');
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');
  const [sosModalOpen, setSosModalOpen] = useState(false);
  const [userProfile, setUserProfile] = useState<UserHealthProfile>(MOCK_USER);
  const [appointments, setAppointments] = useState<Appointment[]>(MOCK_APPOINTMENTS);
  const [activeVideoCallDoc, setActiveVideoCallDoc] = useState<Doctor | null>(null);

  // Initialize IndexedDB persistent storage on load
  useEffect(() => {
    seedInitialOfflineStorage(MOCK_USER, MOCK_APPOINTMENTS).then((data) => {
      if (data.profile) setUserProfile(data.profile);
      if (data.appointments && data.appointments.length > 0) {
        setAppointments(data.appointments);
      }
    });
  }, []);

  const handleBookAppointment = (newApt: Appointment) => {
    setAppointments((prev) => [newApt, ...prev]);
    saveAppointmentToIDB(newApt);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-teal-500 selection:text-slate-950 relative overflow-x-hidden">
      
      {/* Dynamic Background Glow Blobs */}
      <div className="fixed top-0 left-1/4 w-[600px] h-[600px] bg-teal-500/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="fixed bottom-10 right-10 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* Global Navigation */}
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
        onTriggerSOS={() => setSosModalOpen(true)}
      />


      {/* Main Content View Switcher */}
      <main className="pb-16 pt-2 transition-all duration-300">
        
        {/* TAB 1: HOME */}
        {activeTab === 'home' && (
          <div className="space-y-16">
            <Hero
              onNavigate={setActiveTab}
              onTriggerSOS={() => setSosModalOpen(true)}
            />

            {/* Platform Core Feature Cards Grid */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
              <div className="text-center space-y-2">
                <span className="text-xs font-bold text-teal-400 uppercase tracking-widest bg-teal-500/10 px-3 py-1 rounded-full border border-teal-500/20">
                  EVERYTHING YOU NEED IN A MEDICAL EMERGENCY
                </span>
                <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
                  15+ AI Healthcare Services
                </h2>
                <p className="text-sm text-slate-400 max-w-2xl mx-auto">
                  Powered by Gemini 2.5 Flash API, real-time Google Maps GPS API, and ICD-10 medical triage engines.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                {/* Feature 1 */}
                <div
                  onClick={() => setActiveTab('doctors')}
                  className="group p-6 rounded-3xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-teal-500/50 transition-all duration-300 cursor-pointer shadow-xl hover:-translate-y-1"
                >
                  <div className="p-3.5 rounded-2xl bg-teal-500/10 text-teal-400 border border-teal-500/20 w-fit mb-4 group-hover:scale-110 transition-transform">
                    <HeartPulse className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-teal-400 transition-colors">
                    AI Doctor Finder & Slot Booking
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Locate nearby specialists with live distance calculation, verified patient ratings, and 1-click video call booking.
                  </p>
                </div>

                {/* Feature 2 */}
                <div
                  onClick={() => setActiveTab('fraud')}
                  className="group p-6 rounded-3xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-rose-500/50 transition-all duration-300 cursor-pointer shadow-xl hover:-translate-y-1"
                >
                  <div className="p-3.5 rounded-2xl bg-rose-500/10 text-rose-400 border border-rose-500/20 w-fit mb-4 group-hover:scale-110 transition-transform">
                    <FileSearch className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-rose-400 transition-colors">
                    Hospital Bill Fraud Auditor
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Upload hospital bill photos. Gemini AI detects duplicate ICU charges, inflated drug MRPs, and generates dispute PDFs.
                  </p>
                </div>

                {/* Feature 3 */}
                <div
                  onClick={() => setActiveTab('estimator')}
                  className="group p-6 rounded-3xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/50 transition-all duration-300 cursor-pointer shadow-xl hover:-translate-y-1"
                >
                  <div className="p-3.5 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 w-fit mb-4 group-hover:scale-110 transition-transform">
                    <Calculator className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
                    AI Treatment Cost Estimator
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Get accurate itemized expense estimates for surgeries, ICU stays, and medicines before entering a hospital.
                  </p>
                </div>

                {/* Feature 4 */}
                <div
                  onClick={() => setActiveTab('schemes')}
                  className="group p-6 rounded-3xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-amber-500/50 transition-all duration-300 cursor-pointer shadow-xl hover:-translate-y-1"
                >
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 w-fit mb-4 group-hover:scale-110 transition-transform">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                    Ayushman & Govt Scheme Engine
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Check eligibility for PM-JAY and state healthcare schemes to secure up to ₹5,00,000 free medical coverage.
                  </p>
                </div>

                {/* Feature 5 */}
                <div
                  onClick={() => setActiveTab('prescription')}
                  className="group p-6 rounded-3xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-emerald-500/50 transition-all duration-300 cursor-pointer shadow-xl hover:-translate-y-1"
                >
                  <div className="p-3.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 w-fit mb-4 group-hover:scale-110 transition-transform">
                    <Pill className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors">
                    Prescription & Generic Switcher
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Scan handwritten prescriptions to parse drug usages, food warnings, and save up to 85% with generic substitutes.
                  </p>
                </div>

                {/* Feature 6 */}
                <div
                  onClick={() => setActiveTab('symptom')}
                  className="group p-6 rounded-3xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all duration-300 cursor-pointer shadow-xl hover:-translate-y-1"
                >
                  <div className="p-3.5 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 w-fit mb-4 group-hover:scale-110 transition-transform">
                    <HeartPulse className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-indigo-400 transition-colors">
                    Symptom Triage & Risk Predictor
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Evaluate symptoms with AI clinical diagnosis, ICD-10 risk scoring, and emergency first-aid advice.
                  </p>
                </div>

              </div>
            </div>
          </div>
        )}

        {/* TAB 2: NEARBY DOCTORS */}
        {activeTab === 'doctors' && (
          <NearbyDoctorFinder
            onBookAppointment={handleBookAppointment}
            onLaunchVideoConsultation={(doc) => setActiveVideoCallDoc(doc)}
          />
        )}

        {/* TAB 3: BILL FRAUD AUDITOR */}
        {activeTab === 'fraud' && <BillFraudDetector />}

        {/* TAB 4: COST ESTIMATOR */}
        {activeTab === 'estimator' && <CostEstimator />}

        {/* TAB 5: HOSPITALS */}
        {activeTab === 'hospitals' && <HospitalComparator />}

        {/* TAB 6: GOVT SCHEMES */}
        {activeTab === 'schemes' && <GovernmentSchemes />}

        {/* TAB 7: PRESCRIPTION SCANNER */}
        {activeTab === 'prescription' && <PrescriptionScanner />}

        {/* TAB 8: SYMPTOM CHECKER */}
        {activeTab === 'symptom' && <SymptomChecker />}

        {/* TAB 9: AMBULANCE TRACKER */}
        {activeTab === 'ambulance' && <AmbulanceTracker />}

        {/* TAB 10: AI CHATBOT */}
        {(activeTab === 'chat' || activeTab === 'chatbot') && (
          <AIChatbot
            language={currentLanguage}
            onNavigate={setActiveTab}
            onTriggerSOS={() => setSosModalOpen(true)}
          />
        )}

        {/* TAB 11: DASHBOARD (Role-based: User, Doctor, Admin) */}
        {activeTab === 'dashboard' && (
          <>
            {(currentRole === 'patient' || (currentRole as string) === 'user') && (
              <UserDashboard
                userProfile={userProfile}
                appointments={appointments}
                onNavigate={setActiveTab}
                onProfileUpdated={(updated) => setUserProfile(updated)}
                onLaunchVideoConsultation={(apt) => {
                  setActiveVideoCallDoc({
                    id: apt.doctorId,
                    name: apt.doctorName,
                    specialty: apt.doctorSpecialty,
                    imageUrl: apt.doctorImageUrl,
                  } as Doctor);
                }}
              />
            )}

            {currentRole === 'doctor' && (
              <DoctorDashboard
                appointments={appointments}
                onLaunchVideoConsultation={(apt) => {
                  setActiveVideoCallDoc({
                    id: apt.doctorId,
                    name: apt.doctorName,
                    specialty: apt.doctorSpecialty,
                    imageUrl: apt.doctorImageUrl,
                  } as Doctor);
                }}
              />
            )}

            {currentRole === 'admin' && <AdminDashboard />}
          </>
        )}

      </main>

      {/* Floating Emergency SOS Action Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setSosModalOpen(true)}
          className="relative group p-4 rounded-full bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 text-white font-black shadow-2xl shadow-rose-600/50 hover:scale-110 active:scale-95 transition-all flex items-center gap-2"
        >
          <span className="absolute -inset-2 rounded-full bg-rose-600/30 animate-ping pointer-events-none" />
          <ShieldAlert className="w-6 h-6 animate-bounce" />
          <span className="hidden sm:inline font-mono tracking-wider text-xs">EMERGENCY SOS</span>
        </button>
      </div>

      {/* Emergency SOS Modal Overlay */}
      <EmergencySOSModal
        isOpen={sosModalOpen}
        onClose={() => setSosModalOpen(false)}
      />

      {/* Video Consultation Call Window Modal */}
      {activeVideoCallDoc && (
        <VideoConsultation
          doctorName={activeVideoCallDoc.name}
          doctorSpecialty={activeVideoCallDoc.specialty}
          doctorImageUrl={activeVideoCallDoc.imageUrl}
          onEndCall={() => setActiveVideoCallDoc(null)}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 px-4 text-center text-xs text-slate-500 space-y-2">
        <p className="font-bold text-slate-400">MEDI AI • Saving Lives Faster, Smarter & More Affordable</p>
        <p className="text-[11px] max-w-xl mx-auto text-slate-600">
          Medical Disclaimer: MEDI AI is an AI-powered healthcare assistant designed for emergency triage, cost estimation, and health guidance. Always consult a certified medical doctor for severe clinical diagnosis.
        </p>
      </footer>

    </div>
  );
}

export default App;
