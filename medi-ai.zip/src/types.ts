export type Language = 'en' | 'hi' | 'te' | 'ta' | 'kn' | 'ml';

export type UserRole = 'patient' | 'doctor' | 'admin';

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  experienceYears: number;
  rating: number;
  reviewsCount: number;
  feeINR: number;
  hospitalName: string;
  address: string;
  distanceKm: number;
  lat: number;
  lng: number;
  availableNow: boolean;
  videoCallAvailable: boolean;
  homeVisitAvailable?: boolean;
  homeVisitFeeINR?: number;
  languages: string[];
  imageUrl: string;
  phone: string;
  education: string;
  nextSlot: string;
}

export interface Hospital {
  id: string;
  name: string;
  grade: 'Super Specialty' | 'Multi Specialty' | 'Government' | 'Clinic';
  address: string;
  city: string;
  lat: number;
  lng: number;
  distanceKm: number;
  rating: number;
  icuBedsAvailable: number;
  totalIcuBeds: number;
  emergencyRoomStatus: 'Immediate Admission' | 'Wait 15 mins' | 'Full';
  successRatePercent: number;
  cashlessInsuranceAccepted: string[];
  govtSchemesAccepted: string[];
  avgCostAngioplastyINR: number;
  avgCostNormalDeliveryINR: number;
  phone: string;
  ambulanceAvailable: boolean;
  imageUrl: string;
}

export interface EmergencyRequest {
  id: string;
  patientName: string;
  contactNumber: string;
  locationAddress: string;
  lat: number;
  lng: number;
  emergencyType: 'Cardiac' | 'Accident' | 'Pregnancy' | 'Breathing Difficulty' | 'Other';
  status: 'DISPATCHED' | 'EN_ROUTE' | 'ARRIVED' | 'RESOLVED';
  assignedAmbulanceId?: string;
  etaMinutes: number;
  timestamp: string;
}

export interface Medicine {
  id: string;
  brandName: string;
  genericName: string;
  manufacturer: string;
  brandPriceINR: number;
  genericPriceINR: number;
  discountPercent: number;
  dosageForm: string;
  category: string;
  usageDescription: string;
  sideEffects: string[];
  prescriptionRequired: boolean;
}

export interface Pharmacy {
  id: string;
  name: string;
  address: string;
  distanceKm: number;
  lat: number;
  lng: number;
  isOpen24x7: boolean;
  discountOfferedPercent: number;
  phone: string;
  rating: number;
}

export interface BloodBank {
  id: string;
  hospitalName: string;
  address: string;
  lat: number;
  lng: number;
  distanceKm: number;
  phone: string;
  bloodAvailability: {
    'A+': number;
    'A-': number;
    'B+': number;
    'B-': number;
    'O+': number;
    'O-': number;
    'AB+': number;
    'AB-': number;
  };
  lastUpdated: string;
}

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  doctorSpecialty: string;
  doctorImageUrl: string;
  patientName: string;
  date: string;
  timeSlot: string;
  type: 'In-Person' | 'Video Call' | 'Home Visit';
  status: 'CONFIRMED' | 'COMPLETED' | 'CANCELLED';
  feeINR: number;
  notes?: string;
  meetLink?: string;
  homeAddress?: string;
}

export interface FraudReport {
  id: string;
  hospitalName: string;
  billAmountINR: number;
  fairAmountINR: number;
  potentialSavingsINR: number;
  fraudScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  date: string;
  status: 'FLAGGED' | 'IN_DISPUTE' | 'RESOLVED';
  suspiciousCount: number;
}

export interface GovernmentScheme {
  id: string;
  name: string;
  category: string;
  maxBenefitAmount: string;
  eligibilityCriteria: string;
  documentsRequired: string[];
  applyUrl: string;
  summary: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  relation: string;
  phone: string;
  isPrimary?: boolean;
  notes?: string;
}

export interface MedicalRecord {
  id: string;
  title: string;
  category: 'Prescription' | 'Lab Report' | 'Discharge Summary' | 'Vaccination' | 'Insurance Claim' | 'Imaging / X-Ray';
  doctorName?: string;
  hospitalName?: string;
  date: string;
  notes?: string;
  fileDataUrl?: string;
  fileName?: string;
  tags?: string[];
  createdAt: string;
}

export interface UserHealthProfile {
  name: string;
  age: number;
  gender: string;
  bloodGroup: string;
  weightKg: number;
  heightCm: number;
  bmi: number;
  healthScore: number;
  chronicConditions: string[];
  allergies: string[];
  emergencyContacts: EmergencyContact[];
  insurancePolicyNumber?: string;
  insuranceProvider?: string;
  ayushmanId?: string;
  dailyWaterMl: number;
  dailyWaterGoalMl: number;
  dailySleepHours: number;
}

